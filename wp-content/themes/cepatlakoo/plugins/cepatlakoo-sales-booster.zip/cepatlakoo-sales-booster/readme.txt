=== Cepatlakoo Sales Booster ===
This is an extension for WooCommerce plugin, It will promote your recent sales and notify visitors about it. Forked from the original Woo Sales Notify plugin from alisaleem252
Tags: woocommerce, notify, promotion, marketing, sales