<?php
namespace Elementor\TemplateLibrary;

use Elementor\Api;
use Elementor\Controls_Manager;
use Elementor\Element_Base;
use Elementor\Plugin;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Source_Landingpresstemplates extends Source_Base {

	public function get_id() {
		return 'landingpresstemplates';
	}

	public function get_title() {
		return __( 'LandingPress Templates', 'elementor' );
	}

	public function register_data() {}

	public function get_items( $args = [] ) {
		$templates_data = apply_filters( 'landingpress_elementor_templates_data', array() );

		$templates = [];
		if ( ! empty( $templates_data ) ) {
			foreach ( $templates_data as $template_data ) {
				$templates[] = $this->get_item( $template_data );
			}
		}

		if ( ! empty( $args ) ) {
			$templates = wp_list_filter( $templates, $args );
		}

		return $templates;
	}

	/**
	 * @param array $template_data
	 *
	 * @return array
	 */
	public function get_item( $template_data ) {
		if ( isset( $template_data['thumbnail'] ) && $template_data['thumbnail'] ) {
			$thumbnail = $template_data['thumbnail'];
		}
		else {
			$thumbnail = 'https://api.landingpress.net/templates/thumbnails/'.$template_data['id'].'.png';
		}
		return [
			'template_id' => $template_data['id'],
			'source' => $this->get_id(),
			'title' => $template_data['title'],
			'thumbnail' => $thumbnail,
			'date' => date(),
			'author' => 'LandingPress',
			'categories' => [],
			'keywords' => [],
			'isPro' => 0,
			'url' => $template_data['url'],
		];
	}

	public function save_item( $template_data ) {
		return false;
	}

	public function update_item( $new_data ) {
		return false;
	}

	public function delete_template( $item_id ) {
		return false;
	}

	public function export_template( $item_id ) {
		return false;
	}

	public function get_content( $item_id, $context = 'display' ) {
		$url = 'https://api.landingpress.net/templates/contents/'.$item_id.'.json';

		$body_args = [
			// Which API version is used
			'api_version' => ELEMENTOR_VERSION,
			// Which language to return
			'site_lang' => get_bloginfo( 'language' ),
		];

		$body_args = apply_filters( 'elementor/api/get_templates/body_args', $body_args );

		$response = wp_remote_get( $url, [
			'timeout' => 40,
			'body' => $body_args,
		] );

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return false;
		}

		$template_content = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $template_content ) || ! is_array( $template_content ) ) {
			return false;
		}

		if ( empty( $template_content['data'] ) ) {
			return false;
		}

		$data = $template_content['data'];

		if ( ! $data ) {
			return false;
		}

		$data = $this->replace_elements_ids( $data );
		$data = $this->process_export_import_data( $data, 'on_import' );

		return $data;
	}
}
