<?php
/**
This is our function to load shortcodes for LandingPress
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

