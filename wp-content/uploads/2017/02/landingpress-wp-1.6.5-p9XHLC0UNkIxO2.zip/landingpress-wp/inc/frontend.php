<?php
/**
 * Custom template tags for this theme.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package LandingPress
 */

function landingpress_get_nav_menu( $args = array() ) {

	if ( !isset( $args['theme_location'] ) )
		return;

	$transient_active = apply_filters( "landingpress_transient", false );

	$args['echo'] = false;

	$transient_name = 'landingpress_menu_'.$args['theme_location'];
	
	$html = $transient_active ? get_transient( $transient_name  ) : false;

	if( false === $html ) {
		if ( has_nav_menu( $args['theme_location'] ) ) {
			$html = wp_nav_menu( $args );
			if ( $transient_active ) {
				set_transient( $transient_name, $html, DAY_IN_SECONDS );
			}
		}
	}

	return $html;
}

add_action( 'excerpt_more', 'landingpress_excerpt_more' );
function landingpress_excerpt_more( $html ) {
	return ' &hellip;';
}

function landingpress_get_paginate_links( $query = '' ) { 

	if ( !$query ) {
		global $wp_query;
		$query = $wp_query;
	}

	if( isset( $query->max_num_pages ) && $query->max_num_pages <= 1 ) 
		return;

	$big = 999999999; // need an unlikely integer
	$links = paginate_links( array(
		'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
		'format' => '?paged=%#%',
		'current' => max( 1, get_query_var('paged') ),
		'total' => $wp_query->max_num_pages,
		'type' => 'list',
		'prev_next' => true,
		'prev_text' => __('&laquo; Previous', 'landingpress'),
		'next_text' => __('Next &raquo;', 'landingpress'),
	) );

	if ( $links )
		$links = '<nav class="navigation posts-navigation">'.$links.'</nav>';

	return apply_filters( "landingpress_posts_navigation", $links );
}

function landingpress_get_the_post_navigation() {
	
	$links = get_the_post_navigation();

	$links = str_replace( ' role="navigation"', '', $links );

	return apply_filters( "landingpress_post_navigation", $links );
}


function landingpress_get_entry_meta() {

	$meta = '';

	// Hide category and tag text for pages.
	if ( 'post' == get_post_type() ) {
		/* translators: used between list items, there is a space after the comma */
		$categories_list = get_the_category_list( __( ', ', 'landingpress' ) );
		if ( $categories_list ) {
			$categories_list = str_replace( 'rel="category tag"', '', $categories_list );
			$meta .= '<span class="cat-links">' . $categories_list . '</span>';
			$meta .= '<span class="meta-sep">&middot;</span>';
		}
	}

	$time_string = '<span class="time-link"><time class="entry-date published updated" datetime="%1$s">%2$s</time></span>';
	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
		$time_string = '<span class="time-link"><time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time></span>';
	}

	$time_string = sprintf( $time_string,
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() ),
		esc_attr( get_the_modified_date( 'c' ) ),
		esc_html( get_the_modified_date() )
	);

	$meta .= $time_string;

	if ( get_theme_mod( 'landingpress_post_comment' ) ) {
		if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
			$meta .= '<span class="meta-sep">&middot;</span>';
			$meta .= '<span class="comments-link">';
			ob_start();
			comments_popup_link( __( 'Leave a comment', 'landingpress' ), __( '1 Comment', 'landingpress' ), __( '% Comments', 'landingpress' ) );
			$meta .= ob_get_clean();
			$meta .= '</span>';
		}
	}

	ob_start();
	edit_post_link( __( 'Edit', 'landingpress' ), '<span class="meta-sep">&middot;</span><span class="edit-link">', '</span>' );
	$meta .= ob_get_clean();

	return apply_filters( "landingpress_entry_meta", $meta );
}

function landingpress_get_the_term_list( $id, $taxonomy = 'post_tag', $before = '', $sep = '', $after = '' ) {
	$terms = get_the_terms( $id, $taxonomy );

	if ( is_wp_error( $terms ) )
		return $terms;

	if ( empty( $terms ) )
		return false;

	$links = array();

	foreach ( $terms as $term ) {
		$link = get_term_link( $term, $taxonomy );
		if ( is_wp_error( $link ) ) {
			return $link;
		}
		$links[] = '<a href="' . esc_url( $link ) . '">#' . $term->name . '</a>';
	}

	$term_links = apply_filters( "term_links-$taxonomy", $links );

	return $before . join( $sep, $term_links ) . $after;
}

if ( ! function_exists( 'landingpress_link_pages' ) ) :
function landingpress_link_pages() {
	add_filter( 'wp_link_pages_link', 'landingpress_link_pages_link' );
	wp_link_pages( array(
		'before' => '<nav class="page-links"><ul><li class="label">' . esc_html__( 'Pages:', 'landingpress' ) . '</li>',
		'after'  => '</ul></nav>',
	) );
	remove_filter( 'wp_link_pages_link', 'landingpress_link_pages_link' );
}
endif;

if ( ! function_exists( 'landingpress_link_pages_link' ) ) :
function landingpress_link_pages_link( $link ) {
	if ( strpos($link, '</a>') === false ) 
		return '<li class="current"><span>' . $link . '</span></li>';
	else
		return '<li>' . $link . '</li>';
}
endif;

add_action( 'wp_head', 'landingpress_wp_head_seo_meta', 1 );
function landingpress_wp_head_seo_meta() {

	if ( defined('WPSEO_VERSION') || class_exists('All_in_One_SEO_Pack') || class_exists('All_in_One_SEO_Pack_p') || class_exists('HeadSpace_Plugin') || class_exists('Platinum_SEO_Pack') || class_exists('SEO_Ultimate') )
		return;

	if ( !is_singular() )
		return;

	if ( '0' != get_option('blog_public') ) {
		$meta_index = get_post_meta( get_the_ID(), '_landingpress_meta-index', true );
		if ( !$meta_index ) {
			$meta_index = 'index';
		}
		$meta_follow = get_post_meta( get_the_ID(), '_landingpress_meta-follow', true );
		if ( !$meta_follow ) {
			$meta_follow = 'follow';
		}
		echo '<meta name="robots" content="'.esc_attr($meta_index).','.esc_attr($meta_follow).'"/>'."\n";
	}

	$meta_title = get_post_meta( get_the_ID(), '_landingpress_meta-title', true );
	if ( $meta_title ) {
		echo '<meta name="title" content="'.esc_attr($meta_title).'"/>'."\n";
	}

	$meta_description = get_post_meta( get_the_ID(), '_landingpress_meta-description', true );
	if ( $meta_description ) {
		echo '<meta name="description" content="'.esc_attr($meta_description).'"/>'."\n";
	}

	$meta_keywords = get_post_meta( get_the_ID(), '_landingpress_meta-keywords', true );
	if ( $meta_keywords ) {
		echo '<meta name="keywords" content="'.esc_attr($meta_keywords).'"/>'."\n";
	}

}

add_action( 'wp_head', 'landingpress_wp_head_facebook_opengraph', 1 );
function landingpress_wp_head_facebook_opengraph() {

	echo '<meta property="og:site_name" content="'.esc_attr( get_bloginfo( 'name' ) ).'"/>'."\n";

	if ( !is_singular() )
		return;

	echo '<meta property="og:url" content="'.get_permalink( get_the_ID() ).'"/>'."\n";

	$facebook_image_id = get_post_meta( get_the_ID(), '_landingpress_facebook-image', true );
	if ( $facebook_image_id ) {
		$facebook_image = wp_get_attachment_url( $facebook_image_id );
		if ( $facebook_image ) {
			echo '<meta property="og:image" content="'.$facebook_image.'"/>'."\n";
		}
	}

	$facebook_title = get_post_meta( get_the_ID(), '_landingpress_facebook-title', true );
	if ( $facebook_title ) {
		echo '<meta property="og:title" content="'.esc_attr($facebook_title).'"/>'."\n";
	}

	$facebook_description = get_post_meta( get_the_ID(), '_landingpress_facebook-description', true );
	if ( $facebook_description ) {
		echo '<meta property="og:description" content="'.esc_attr($facebook_description).'"/>'."\n";
	}

}

function landingpress_get_related_posts( $post_id ) {
	if ( !$post_id )
		return;

	global $wpdb, $post;

	$transient_active = apply_filters( "landingpress_transient", false );

	$transient_name = 'landingpress_related_' . $post_id;

	$related_posts  = $transient_active ? get_transient( $transient_name ) : false;

	// We want to query related posts if they are not cached
	if ( false === $related_posts ) {

		$number = 10;

		// Related products are found from category and tag
		$tags_array = array(0);
		$cats_array = array(0);
		$tags = '';
		$cats = '';

		// Get tags
		$terms = wp_get_post_terms($post_id, 'post_tag');
		foreach ($terms as $term) {
			$tags_array[] = $term->term_id;
		}
		$tags = implode(',', $tags_array);

		$terms = wp_get_post_terms($post_id, 'category');
		foreach ($terms as $term) {
			$cats_array[] = $term->term_id;
		}
		$cats = implode(',', $cats_array);

		$q = "
			SELECT p.ID
			FROM $wpdb->term_taxonomy AS tt, $wpdb->term_relationships AS tr, $wpdb->posts AS p
			WHERE 
				p.ID != $post_id
				AND p.post_status = 'publish'
				AND p.post_type = 'post'
				AND
				(
					(
						tt.taxonomy ='category'
						AND tt.term_taxonomy_id = tr.term_taxonomy_id
						AND tr.object_id  = p.ID
						AND tt.term_id IN ($cats)
					)
					OR 
					(
						tt.taxonomy ='post_tag'
						AND tt.term_taxonomy_id = tr.term_taxonomy_id
						AND tr.object_id  = p.ID
						AND tt.term_id IN ($tags)
					)
				)
			GROUP BY tr.object_id
			ORDER BY RAND()
			LIMIT $number;";

		$related_posts = $wpdb->get_col($q);

		if ( $transient_active ) {
			set_transient( $transient_name, $related_posts, DAY_IN_SECONDS );
		}
	}

	return $related_posts;
}

add_action( 'init', 'landingpress_page_search', 99 );
function landingpress_page_search() {
	global $wp_post_types;
	if ( post_type_exists( 'page' ) ) {
		$wp_post_types['page']->exclude_from_search = true;
	}
}

add_filter('wp_nav_menu_items','landingpress_header_searchform', 10, 2);
function landingpress_header_searchform($items, $args) {
	if( get_theme_mod('landingpress_menu_search', '1') && $args->theme_location == 'header' ) {
		$form = get_search_form( false );
		$form = str_replace( ' role="search"', '', $form );
		$items .= '<li class="header-searchform">' . $form . '</li>';
	}
	return $items;
}

add_filter('prepend_attachment', 'landingpress_prepend_image');
function landingpress_prepend_image( $p ) {
	$post = get_post();

	if ( wp_attachment_is( 'image', $post ) ) {
		$p = '<p class="attachment">';
		$p .= wp_get_attachment_link(0, 'post-thumbnail', false);
		$p .= '</p>';
	}

	return $p;
}

function landingpress_get_image( $args = array() ) {
	$defaults = apply_filters( 'landingpress_get_image_defaults', array(
		'post_id' => null,
		'image_id' => null,
		'size' => 'post-thumbnail',
		'fallback' => null,
		'class' => 'entry-image',
		'alt' => null,
		'link' => false,
		'before' => '',
		'after' => '',
	) );

	$args = wp_parse_args( $args, $defaults );

	extract( $args );

	global $post;

	$html = '';
	$link_to = '';
	$link_class = $class ? $class.'-link' : '';

	$attr = array( 'class' => $class );
	if ( $alt ) {
		$attr['alt'] = $alt;
	}

	if ( !$post_id && $image_id ) {
		$html = wp_get_attachment_image( $image_id, $size, false, $attr );
	}
	else {
		if ( !$post_id ) {
			$post_id = $post->ID;
		}
		if ( has_post_thumbnail( $post_id ) ) {
			$html = get_the_post_thumbnail( $post_id, $size, $attr );
		}
		if ( $link == 'attachment' ) {
			$image_id = get_post_thumbnail_id();
		}
	}

	if ( !$html && get_post_type( $post_id ) == 'post' && $fallback == 'attachment' ) {
		$image_ids = array_keys(
			get_children(
				array(
					'post_parent'    => $post->ID,
					'post_type'	     => 'attachment',
					'post_mime_type' => 'image',
					'orderby'        => 'menu_order',
					'order'	         => 'ASC',
				)
			)
		);
		if ( isset( $image_ids[0] ) ) {
			$image_id = $image_ids[0];
		}

		if ( $image_id ) {
			$html = wp_get_attachment_image( $image_id, $size, false, $attr );

			/* auto featured image */
			// if ( get_post_type() == 'post' ) {
			// 	set_post_thumbnail( $post, $id );
			// }
		}
	}

	if ( $html ) {

		if ( $link ) {
			if ( $link == 'post' ) {
				$link_to = $post_id ? get_permalink( $post_id ) : get_permalink();
			}
			elseif ( $link == 'attachment' ) {
				$link_to = $image_id ? get_permalink( $image_id ) : get_permalink();
			}
			elseif ( $link == 'image' ) {
				if ( $image_id ) {
					$link_to = wp_get_attachment_image_url( $image_id, 'full' );
				}
				elseif ( $post_id ) {
					$link_to = get_the_post_thumbnail_url( $post_id, 'full' );
				}
			}
			else {
				$link_to = esc_url( $link );
			}
		}

		if ( $link_to ) {
			$html = sprintf( '%s<a href="%s" class="%s">%s</a>%s', $before, $link_to, $link_class, $html, $after );
		}
		else {
			$html = sprintf( '%s %s %s', $before, $html, $after );
		}

	}

	return $html;
}

add_filter( 'get_the_archive_title', 'landingpress_get_the_archive_title' );
function landingpress_get_the_archive_title( $output ) {
	$output = str_replace( 'Category: ', '', $output );
	return $output;
}

add_action( 'wp_head', 'landingpress_output_style', 25 );
function landingpress_output_style() {
	$style = apply_filters( "landingpress_style", '' );
	if ( $style ) {
		if ( is_ssl() ) {
			$style = str_replace( 'http://', 'https://', $style );
		}
		echo '<style type="text/css">'."\n".$style."\n".'</style>'."\n";
	}
}

add_filter( 'landingpress_style', 'landingpress_style_header_image' );
function landingpress_style_header_image( $style ) {
	$placement = get_theme_mod( 'landingpress_header_placement' );
	if ( $placement && 'background' != $placement ) 
		return $style;
	$image = get_header_image();
	if ( $image ) {
		$image = preg_replace( '#^(://|[^/])+#', '', $image );
		$style .= '.site-branding{background-image:url('.esc_url($image).')}';
	}
	return $style;
}

add_filter( 'landingpress_style', 'landingpress_style_customize' );
function landingpress_style_customize( $style ) {
	$fields = apply_filters( 'landingpress_customize_controls', array() );
	if ( ! empty( $fields ) ) {
		foreach ( $fields as $field ) {
			$defaults = array(
				'setting'				=> '',
				'type'					=> '',
				'default'				=> '',
				'style'					=> '',
			);
			$field = wp_parse_args( $field, $defaults );
			if ( in_array( $field['type'], array( 'color', 'slider' ) ) && $field['setting'] && !empty( $field['style'] ) ) {
				if ( $value = get_theme_mod( $field['setting'], $field['default'] ) ) {
					$style .= str_replace( '[value]', $value, $field['style'] );
				}
			}
			elseif ( in_array( $field['type'], array( 'radio', 'select', 'radio-buttonset', 'radio-image' ) ) && $field['setting'] && !empty( $field['style'] ) ) {
				if ( $value = get_theme_mod( $field['setting'], $field['default'] ) ) {
					if ( isset( $field['style'][$value] ) ) {
						$style .= $field['style'][$value];
					}
				}
			}
			elseif ( in_array( $field['type'], array( 'custom-css' ) ) && $field['setting'] ) {
				if ( $value = get_theme_mod( $field['setting'], $field['default'] ) ) {
					if ( function_exists( 'landingpress_minify_css' ) ) {
						$style .= landingpress_minify_css( $value );
					}
					else {
						$style .= $value;
					}
				}
			}
		}
	}
	return $style;
}

add_filter( 'clean_url', 'landingpress_defer_parsing_of_js', 11, 1 );
function landingpress_defer_parsing_of_js ( $url ) {
	if ( is_admin() ) {
		return $url;
	}
	if ( get_theme_mod('landingpress_optimization_defer', '1') ) {
		if ( FALSE === strpos( $url, '.js' ) ) {
			return $url;
		}
		// if ( ! get_theme_mod('landingpress_optimization_jquery') ) {
			if ( strpos( $url, 'jquery.js' ) ) 
				return $url;
		// }
		return "$url' defer='defer";
	}
	else {
		return $url;

	}
}

// add_filter( 'script_loader_src', 'landingpress_remove_script_version', 15, 1 );
// add_filter( 'style_loader_src', 'landingpress_remove_script_version', 15, 1 );
function landingpress_remove_script_version( $src ){
	if ( get_theme_mod('landingpress_optimization_version', '') ) {
		$parts = explode( '?ver', $src );
		return $parts[0];
	}
	else {
		return $src;
	}
}

add_action( 'wp_enqueue_scripts', 'landingpress_jquery_group', 5 );
function landingpress_jquery_group() {
	if ( get_theme_mod('landingpress_optimization_jquery') ) {
		wp_scripts()->add_data( 'jquery', 'group', 1 );
		wp_scripts()->add_data( 'jquery-core', 'group', 1 );
		wp_scripts()->add_data( 'jquery-migrate', 'group', 1 );
	}
}

add_action( 'wp_footer', 'landingpress_output_script', 99 );
function landingpress_output_script() {
	$script = apply_filters( "landingpress_script", '' );
	if ( $script ) {
		if ( function_exists( 'landingpress_minify_js' ) ) {
			$script = landingpress_minify_js( $script );
		}
		echo '<script type="text/javascript">'."\n".$script."\n".'</script>'."\n";
	}
}

add_action( 'wp_head', 'landingpress_script_header', 99 );
function landingpress_script_header() {
	if ( !get_theme_mod('landingpress_script_header') )
		return;

	echo get_theme_mod('landingpress_script_header');
}

add_action( 'wp_footer', 'landingpress_script_footer', 99 );
function landingpress_script_footer() {
	if ( !get_theme_mod('landingpress_script_footer') )
		return;
	
	echo get_theme_mod('landingpress_script_footer');
}

function landingpress_get_contact_form() {
	$args = array(
		'email' => get_bloginfo('admin_email'),
		'subject' => __( 'Message via the contact form', 'landingpress' ),
		'sendcopy' => 'yes',
		'question' => '',
		'answer' => '',
		'button_text' => __( 'Submit', 'landingpress' )
	);
	extract( $args );
	if( trim($email) == '' )
		$email = get_bloginfo('admin_email');
	
	$html = '';
	$error_messages = array();
	$notification = false;
	$email_sent = false;
	if ( ( count( $_POST ) > 3 ) && isset( $_POST['submitted'] ) ) {
		if ( isset ( $_POST['checking'] ) && $_POST['checking'] != '' )
			$error_messages['checking'] = 1;
		if ( isset ( $_POST['contact-name'] ) && $_POST['contact-name'] != '' )
			$message_name = $_POST['contact-name'];
		else 
			$error_messages['contact-name'] = __( 'Please enter your name', 'landingpress' );
		if ( isset ( $_POST['contact-email'] ) && $_POST['contact-email'] != '' && is_email( $_POST['contact-email'] ) )
			$message_email = $_POST['contact-email'];
		else 
			$error_messages['contact-email'] = __( 'Please enter your email address (and please make sure it\'s valid)', 'landingpress' );
		if ( isset ( $_POST['contact-message'] ) && $_POST['contact-message'] != '' )
			$message_body = $_POST['contact-message'] . "\n\r\n\r";
		else 
			$error_messages['contact-message'] = __( 'Please enter your message', 'landingpress' );
		if ( $question && $answer ) {
			if ( isset ( $_POST['contact-quiz'] ) && $_POST['contact-quiz'] != '' ) {
				$message_quiz = $_POST['contact-quiz']; 
				if ( esc_attr( $message_quiz ) != esc_attr( $answer ) )
					$error_messages['contact-quiz'] = __( 'Your answer was wrong!', 'landingpress' );
			}
			else {
				$error_messages['contact-quiz'] = __( 'Please enter your answer', 'landingpress' );
			}
		}
		if ( count( $error_messages ) ) {
			$notification = '<p class="contact-error">' . __( 'There were one or more errors while submitting the form.', 'landingpress' ) . '</p>';
		} 
		else {
			$ipaddress = '';
			if (isset($_SERVER['HTTP_CLIENT_IP']) && $_SERVER['HTTP_CLIENT_IP'])
				$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
			else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'])
				$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
			else if(isset($_SERVER['HTTP_X_FORWARDED']) && $_SERVER['HTTP_X_FORWARDED'])
				$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
			else if(isset($_SERVER['HTTP_FORWARDED_FOR']) && $_SERVER['HTTP_FORWARDED_FOR'])
				$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
			else if(isset($_SERVER['HTTP_FORWARDED']) && $_SERVER['HTTP_FORWARDED'])
				$ipaddress = $_SERVER['HTTP_FORWARDED'];
			else if(isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'])
				$ipaddress = $_SERVER['REMOTE_ADDR'];
			else
				$ipaddress = 'UNKNOWN';
			$useragent = $_SERVER['HTTP_USER_AGENT'];
			$message_body = __( 'Email:', 'landingpress' ) . ' '. $message_email . "\r\n\r\n" . $message_body;
			$message_body = __( 'Name:', 'landingpress' ) . ' '. $message_name . "\r\n" . $message_body;
			$message_body = $message_body."\r\n\r\n".__( 'IP Address:', 'landingpress' ).$ipaddress . "\r\n" . __( 'User Agent:', 'landingpress' ).$useragent;
			
			$headers = array();
			$headers[] = 'From: '.$message_name.' <' . $email . '>';
			$headers[] = 'Reply-To: '.$message_email;
			$email_sent = wp_mail($email, $subject, $message_body, $headers);
			
			if ( $sendcopy == 'yes' ) {
				// Send a copy of the e-mail to the sender, if specified.
				if ( isset( $_POST['send-copy'] ) && $_POST['send-copy'] == 'true' ) {
					$subject = __( '[COPY]', 'landingpress' ) . ' ' . $subject;
					$headers = array();
					$headers[] = 'From: '.get_bloginfo('name').' <' . $email . '>';
					$headers[] = 'Reply-To: '.$email;
					$email_sent = wp_mail($message_email, $subject, $message_body, $headers);
				}
			}
			
			if( $email_sent == true ) {
				$notification = '<p class="contact-error">' . __( 'Your email was successfully sent.', 'landingpress' ) . '</p>';
			}
			else {
				$notification = '<p class="contact-error">' . __( 'There were technical error while submitting the form. Sorry for the inconvenience.', 'landingpress' ) . '</p>';
			}
	
		}
	}

	if( $email_sent == true ) {
		$html .= $notification;
	}
	else {
	
		$html .= '<div class="contact-form">' . "\n";
		$html .= $notification;
		if ( $email == '' ) {
			$html .= '<p class="contact-error">' . __( 'E-mail has not been setup properly. Please add your contact e-mail!', 'landingpress' ) . '</p>';
		} 
		else {
			$html .= '<form action="" id="contact-form" method="post">' . "\n";
			$html .= '<fieldset class="forms">' . "\n";
			$contact_name = '';
			if( isset( $_POST['contact-name'] ) ) { $contact_name = $_POST['contact-name']; }
			$contact_email = '';
			if( isset( $_POST['contact-email'] ) ) { $contact_email = $_POST['contact-email']; }
			$contact_message = '';
			if( isset( $_POST['contact-message'] ) ) { $contact_message = stripslashes( $_POST['contact-message'] ); }
			
			$html .= '<p class="field-contact-name">' . "\n";
			$html .= '<input placeholder="' . __( 'Your Name', 'landingpress' ) . '" type="text" name="contact-name" id="contact-name" value="' . esc_attr( $contact_name ) . '" class="txt requiredField" />' . "\n";
			if( array_key_exists( 'contact-name', $error_messages ) ) {
				$html .= '<span class="contact-error">' . $error_messages['contact-name'] . '</span>' . "\n";
			}
			$html .= '</p>' . "\n";

			$html .= '<p class="field-contact-email">' . "\n";
			$html .= '<input placeholder="' . __( 'Your Email', 'landingpress' ) . '" type="text" name="contact-email" id="contact-email" value="' . esc_attr( $contact_email ) . '" class="txt requiredField email" />' . "\n";
			if( array_key_exists( 'contact-email', $error_messages ) ) {
				$html .= '<span class="contact-error">' . $error_messages['contact-email'] . '</span>' . "\n";
			}
			$html .= '</p>' . "\n";

			$html .= '<p class="field-contact-message">' . "\n";
			$html .= '<textarea placeholder="' . __( 'Your Message', 'landingpress' ) . '" name="contact-message" id="contact-message" rows="10" cols="30" class="textarea requiredField">' . esc_textarea( $contact_message ) . '</textarea>' . "\n";
			if( array_key_exists( 'contact-message', $error_messages ) ) {
				$html .= '<span class="contact-error">' . $error_messages['contact-message'] . '</span>' . "\n";
			}
			$html .= '</p>' . "\n";

			if ( $question && $answer ) {
				$html .= '<p class="field-contact-quiz">' . "\n";
				$html .= $question.'<br/>' . "\n";
				$html .= '<input placeholder="' . __( 'Your Answer', 'landingpress' ) . '" type="text" name="contact-quiz" id="contact-quiz" value="" class="txt requiredField quiz" />' . "\n";
				if( array_key_exists( 'contact-quiz', $error_messages ) ) {
					$html .= '<span class="contact-error">' . $error_messages['contact-quiz'] . '</span>' . "\n";
				}
				$html .= '</p>' . "\n";
			}
			
			if ( $sendcopy == 'yes' ) {
				$send_copy = '';
				if(isset($_POST['send-copy']) && $_POST['send-copy'] == true) {
					$send_copy = ' checked="checked"';
				}
				$html .= '<p class="inline"><input type="checkbox" name="send-copy" id="send-copy" value="true"' . $send_copy . ' />&nbsp;&nbsp;<label for="send-copy">' . __( 'Send a copy of this email to you', 'landingpress' ) . '</label></p>' . "\n";
			}

			$checking = '';
			if(isset($_POST['checking'])) {
				$checking = $_POST['checking'];
			}

			$html .= '<p class="screen-reader-text"><label for="checking" class="screen-reader-text">' . __('If you want to submit this form, do not enter anything in this field', 'landingpress') . '</label><input type="text" name="checking" id="checking" class="screen-reader-text" value="' . esc_attr( $checking ) . '" /></p>' . "\n";

			$html .= '<p class="buttons"><input type="hidden" name="submitted" id="submitted" value="true" /><input id="contactSubmit" type="submit" value="' . $button_text . '" /></p>';

			$html .= '</fieldset>' . "\n";
			$html .= '</form>' . "\n";

			$html .= '</div><!--/.post .contact-form-->' . "\n";

		}
	}
	return $html;
}
/**
 * Disable recent comments styling
 * http://www.narga.net/how-to-remove-or-disable-comment-reply-js-and-recentcomments-from-wordpress-header
 */
add_action( 'widgets_init', 'landingpress_remove_recent_comments_style' );
function landingpress_remove_recent_comments_style() {
	global $wp_widget_factory;
	remove_action( 'wp_head', array( $wp_widget_factory->widgets['WP_Widget_Recent_Comments'], 'recent_comments_style' ) );
}

add_action('init', 'landingpress_deregister_wp_embed');
function landingpress_deregister_wp_embed() {
	if (!is_admin()) {
		wp_deregister_script('wp-embed');
	}
}

add_action( 'landingpress_content_before', 'landingpress_output_page_header' );
function landingpress_output_page_header() {
	if ( is_archive() ) {
		echo landingpress_get_breadcrumb();
		echo '<header class="page-header">';
		the_archive_title( '<h1 class="page-title">', '</h1>' );
		the_archive_description( '<div class="taxonomy-description">', '</div>' );
		echo '</header>';
	}
	elseif ( is_search() ) {
		echo landingpress_get_breadcrumb();
		echo '<header class="page-header">';
		echo '<h1 class="page-title">'.sprintf( __( 'Search Results for: %s', 'landingpress' ), '<span>' . get_search_query() . '</span>' ).'</h1>';
		echo '</header>';
	}
	else {
		echo landingpress_get_breadcrumb();
	}	
}

add_action( 'landingpress_entry_header_post_after', 'landingpress_output_share_social', 10 );
add_action( 'landingpress_entry_header_page_after', 'landingpress_output_share_social', 10 );
add_action( 'landingpress_entry_header_attachment_after', 'landingpress_output_share_social', 10 );
add_action( 'landingpress_entry_content_post_after', 'landingpress_output_share_social', 20 );
add_action( 'landingpress_entry_content_page_after', 'landingpress_output_share_social', 20 );
add_action( 'landingpress_entry_content_attachment_after', 'landingpress_output_share_social', 20 );
function landingpress_output_share_social() {

	$filter = current_filter();

	$show = false;
	if ( 'landingpress_entry_header_post_after' == $filter && get_theme_mod('landingpress_post_share_before', '0') ) {
		$show = true;
	}
	elseif ( 'landingpress_entry_content_post_after' == $filter && get_theme_mod('landingpress_post_share_after', '1') ) {
		$show = true;
	}
	elseif ( 'landingpress_entry_header_page_after' == $filter && get_theme_mod('landingpress_page_share_before', '0') ) {
		$show = true;
	}
	elseif ( 'landingpress_entry_content_page_after' == $filter && get_theme_mod('landingpress_page_share_after', '0') ) {
		$show = true;
	}
	elseif ( 'landingpress_entry_header_attachment_after' == $filter && get_theme_mod('landingpress_attachment_share_before', '0') ) {
		$show = true;
	}
	elseif ( 'landingpress_entry_content_attachment_after' == $filter && get_theme_mod('landingpress_attachment_share_after', '0') ) {
		$show = true;
	}

	if ( !$show ) {
		return;
	}

	$share_url = get_permalink();
	$share_title = get_the_title();
	$share_via = get_bloginfo( 'name' );
	$share_image = get_the_post_thumbnail_url( null, 'full' );

	echo '<div class="share-social">';
	echo '<span class="share-label screen-reader-text">'.__( 'Share on', 'landingpress' ).' </span>';
	echo '<a class="share-link share-facebook" rel="nofollow" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u='.esc_url($share_url).'"><i class="fa fa-facebook"></i> Facebook</a>';
	echo '<a class="share-link share-twitter" rel="nofollow" target="_blank" href="https://twitter.com/intent/tweet?text='.urlencode($share_title).'&amp;url='.esc_url($share_url).'&amp;via='.urlencode($share_via).'"><i class="fa fa-twitter"></i> Twitter</a>';
	echo '<a class="share-link share-googleplus" rel="nofollow" target="_blank" href="https://plus.google.com/share?url='.esc_url($share_url).'"><i class="fa fa-google-plus"></i> Google+</a>';
	if ( $share_image ) {
		echo '<a class="share-link share-pinterest" rel="nofollow" target="_blank" href="https://pinterest.com/pin/create/button/?url='.esc_url($share_url).'&amp;media='.esc_url($share_image).'&amp;description='.urlencode($share_title).'"><i class="fa fa-pinterest"></i> Pin It</a>';
	}
	echo '<a class="share-link share-buffer" rel="nofollow" target="_blank" href="https://bufferapp.com/add?url='.esc_url($share_url).'&amp;text='.urlencode($share_title).'">Buffer</a>';
	echo '</div>';
}

add_action( 'landingpress_entry_post_after', 'landingpress_output_related', 10 );
add_action( 'landingpress_entry_attachment_after', 'landingpress_output_related', 10 );
function landingpress_output_related() {
	if ( get_theme_mod( 'landingpress_'.get_post_type().'_related', '1' ) ) {
		get_template_part( 'related' );
	}
}

add_action( 'landingpress_entry_page_after', 'landingpress_output_comments', 20 );
add_action( 'landingpress_entry_post_after', 'landingpress_output_comments', 20 );
add_action( 'landingpress_entry_attachment_after', 'landingpress_output_comments', 20 );
function landingpress_output_comments() {
	if ( !landingpress_is_comments_active() )
		return;
	if ( get_theme_mod( 'landingpress_'.get_post_type().'_comments', '1' ) ) {
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}
	}
}

add_action( 'landingpress_site_content_before', 'landingpress_output_ads', 10 );
add_action( 'landingpress_site_content_after', 'landingpress_output_ads', 10 );
add_action( 'landingpress_entry_content_post_before', 'landingpress_output_ads', 10 );
add_action( 'landingpress_entry_content_post_after', 'landingpress_output_ads', 10 );
add_action( 'landingpress_entry_after_row1', 'landingpress_output_ads', 10 );
add_action( 'landingpress_entry_after_row2', 'landingpress_output_ads', 10 );
add_action( 'landingpress_entry_after_row3', 'landingpress_output_ads', 10 );
function landingpress_output_ads() {

	$output = '';
	$class = 'marketing-unit';
	$filter = current_filter();

	if ( 'landingpress_site_content_before' == $filter ) {
		$output = get_theme_mod('landingpress_ad_site_content_before');
		$class .= ' marketing-site-content-top';
	}
	elseif ( 'landingpress_site_content_after' == $filter ) {
		$output = get_theme_mod('landingpress_ad_site_content_after');
		$class .= ' marketing-site-content-bottom';
	}
	elseif ( 'landingpress_entry_content_post_before' == $filter ) {
		$output = get_theme_mod('landingpress_ad_post_content_before');
		$class .= ' marketing-post-content-top';
	}
	elseif ( 'landingpress_entry_content_post_after' == $filter ) {
		$output = get_theme_mod('landingpress_ad_post_content_after');
		$class .= ' marketing-post-content-bottom';
	}
	elseif ( 'landingpress_entry_after_row1' == $filter && !is_search() ) {
		$output = get_theme_mod('landingpress_ad_archive_row1_after');
		$class .= ' marketing-post-row';
	}
	elseif ( 'landingpress_entry_after_row2' == $filter && !is_search() ) {
		$output = get_theme_mod('landingpress_ad_archive_row2_after');
		$class .= ' marketing-post-row';
	}
	elseif ( 'landingpress_entry_after_row3' == $filter && !is_search() ) {
		$output = get_theme_mod('landingpress_ad_archive_row3_after');
		$class .= ' marketing-post-row';
	}

	if ( $output ) {
		printf( '<div class="%s">%s</div>', $class, $output );
	}

}

add_filter( 'post_class', 'landingpress_post_class', 50 );
function landingpress_post_class( $classes ) {
	if ( in_array( 'hentry', $classes ) ) {
		$classes = array_diff( $classes, array( 'hentry' ) );
		$classes[] = 'entry';
	}
	$image_opt = get_theme_mod( 'landingpress_archive_image', 'featured' );
	$content_opt = get_theme_mod( 'landingpress_archive_content' );	
	if ( !is_singular() && ( 'thumb-left' == $image_opt || 'thumb-right' == $image_opt ) && 'excerpt' == $content_opt ) {
		$classes[] = 'entry-summary';
	}
	return $classes;
}

remove_action('wp_head', 'print_emoji_detection_script', 7 );
remove_action('wp_print_styles', 'print_emoji_styles' );
remove_action('wp_head', 'rest_output_link_wp_head', 10 );
remove_action('wp_head', 'wp_oembed_add_discovery_links', 10 );
remove_action('wp_head', 'wp_generator');

add_filter( 'wp_calculate_image_srcset_meta', '__return_null' );

add_action( 'wp', 'landingpress_simple_postviews_hits' );
function landingpress_simple_postviews_hits() {
 	if ( class_exists('AJAX_Hits_Counter') )
 		return;
 	if ( !is_singular() )
 		return;
	$post_ID = get_the_ID(); 	
    $count_key = 'hits'; 
    $count = get_post_meta($post_ID, $count_key, true);
    if ( '' == $count ){
        $count = 0;
        delete_post_meta($post_ID, $count_key);
        add_post_meta($post_ID, $count_key, '0');
    }
    else {
        $count++;
        update_post_meta($post_ID, $count_key, $count);
    }
}

function landingpress_is_sidebar_active() {
	return apply_filters( 'landingpress_is_sidebar_active', true );
}

function landingpress_is_header_active() {
	return apply_filters( 'landingpress_is_header_active', true );
}

function landingpress_is_menu_active() {
	return apply_filters( 'landingpress_is_menu_active', true );
}

function landingpress_is_footerwidgets_active() {
	return apply_filters( 'landingpress_is_footerwidgets_active', true );
}

function landingpress_is_footer_active() {
	return apply_filters( 'landingpress_is_footer_active', true );
}

function landingpress_is_breadcrumb_active() {
	return apply_filters( 'landingpress_is_breadcrumb_active', true );
}

function landingpress_is_title_active() {
	return apply_filters( 'landingpress_is_title_active', true );
}

function landingpress_is_comments_active() {
	return apply_filters( 'landingpress_is_comments_active', true );
}

add_action( 'body_class', 'landingpress_body_class_page_layout' );
function landingpress_body_class_page_layout( $classes ) {
	if ( ! landingpress_is_sidebar_active() ) {
		$classes[] = 'page-sidebar-inactive';
	}
	return $classes;
}

add_action( 'body_class', 'landingpress_body_class_element_active' );
function landingpress_body_class_element_active( $classes ) {
	$classes[] = landingpress_is_header_active() ? 'header-active' : 'header-inactive';
	if ( landingpress_is_menu_active() && has_nav_menu( 'header' ) ) {
		$classes[] = 'header-menu-active';
		if ( get_theme_mod( 'landingpress_menu_sticky', '1' ) ) {
			$classes[] = 'header-menu-sticky';
		}
	}
	$classes[] = landingpress_is_footer_active() ? 'footer-active' : 'footer-inactive';
	return $classes;
}

add_action( 'body_class', 'landingpress_body_class_page_width' );
function landingpress_body_class_page_width( $classes ) {
	if ( is_singular('post') || is_page() ) {
		if ( $width = get_post_meta( get_the_ID(), '_landingpress_page_width', true ) ) {
			$classes[] = 'page-width-'.$width;
		}
	}
	return $classes;
}

add_action( 'wp', 'landingpress_page_layout_filter' );
function landingpress_page_layout_filter() {
	if ( is_admin() )
		return;
	if ( is_singular('post') || is_singular('page') ) {
		if ( 'yes' == get_post_meta( get_the_ID(), '_landingpress_hide_sidebar', true ) ) {
			add_filter('landingpress_is_sidebar_active', '__return_false');
		}
		if ( 'yes' == get_post_meta( get_the_ID(), '_landingpress_hide_header', true ) ) {
			add_filter('landingpress_is_header_active', '__return_false');
		}
		if ( 'yes' == get_post_meta( get_the_ID(), '_landingpress_hide_menu', true ) ) {
			add_filter('landingpress_is_menu_active', '__return_false');
		}
		if ( 'yes' == get_post_meta( get_the_ID(), '_landingpress_hide_footerwidgets', true ) ) {
			add_filter('landingpress_is_footerwidgets_active', '__return_false');
		}
		if ( 'yes' == get_post_meta( get_the_ID(), '_landingpress_hide_footer', true ) ) {
			add_filter('landingpress_is_footer_active', '__return_false');
		}
		if ( 'yes' == get_post_meta( get_the_ID(), '_landingpress_hide_breadcrumb', true ) ) {
			add_filter('landingpress_is_breadcrumb_active', '__return_false');
		}
		if ( 'yes' == get_post_meta( get_the_ID(), '_landingpress_hide_title', true ) ) {
			add_filter('landingpress_is_title_active', '__return_false');
		}
		if ( 'yes' == get_post_meta( get_the_ID(), '_landingpress_hide_comments', true ) ) {
			add_filter('landingpress_is_comments_active', '__return_false');
		}
	}
	if ( get_theme_mod( 'landingpress_header_hide' ) ) {
		add_filter('landingpress_is_header_active', '__return_false');
	}
}

add_action( 'template_redirect', 'landingpress_singular_redirect_url', 20 );
function landingpress_singular_redirect_url() {
	if ( ! is_singular() )
		return;
	if ( $url = get_post_meta( get_the_ID(), '_landingpress_redirect', true ) ) {
		wp_redirect( esc_url_raw( $url ), 301 );
		exit;
	}
}

add_action( 'body_class', 'landingpress_body_class_image_header_active' );
function landingpress_body_class_image_header_active( $classes ) {
	$header_image = get_header_image();
	$header_placement = get_theme_mod( 'landingpress_header_placement', 'background' );
	if ( $header_image && ( 'background' == $header_placement || 'image' == $header_placement || 'image_title_top' == $header_placement ) ) {
		$classes[] = 'header-image-active';
	}
	return $classes;
}

add_filter( 'landingpress_style', 'landingpress_style_googlefonts' );
function landingpress_style_googlefonts( $style ) {
	$font_body = get_theme_mod('landingpress_font_body');
	$font_heading = get_theme_mod('landingpress_font_heading');
	if ( $font_body && $font_body != 'default' ) {
		$font_body = str_replace( ')', '', $font_body );
		$font_body = explode( ' (', $font_body );
		if ( is_array( $font_body ) && 2 == count($font_body) ) {
			if ( in_array( $font_body[1], array( 'serif', 'sans-serif' ) ) ) {
				$style .= 'body,.site-description{font-family:"'.$font_body[0].'", '.$font_body[1].';}';
			}
			else {
				$style .= 'body,.site-description{font-family:"'.$font_body[0].'";}';
			}
		}
	}
	if ( $font_heading && $font_heading != 'default' ) {
		$font_heading = str_replace( ')', '', $font_heading );
		$font_heading = explode( ' (', $font_heading );
		if ( is_array( $font_heading ) && 2 == count($font_heading) ) {
			if ( in_array( $font_heading[1], array( 'serif', 'sans-serif' ) ) ) {
				$style .= 'h1,h2,h3,h4,h5,h6,.site-title{font-family:"'.trim($font_heading[0]).'", '.$font_heading[1].';}';
			}
			else {
				$style .= 'h1,h2,h3,h4,h5,h6,.site-title{font-family:"'.trim($font_heading[0]).'";}';
			}
		}
	}
	return $style;
}

add_action( 'wp_head', 'landingpress_enqueue_googlefonts' );
function landingpress_enqueue_googlefonts() {
	$font_body = get_theme_mod('landingpress_font_body');
	$font_heading = get_theme_mod('landingpress_font_heading');
	$fonts = array();
	if ( $font_body && $font_body != 'default' ) {
		$font_body = str_replace( ')', '', $font_body );
		$font_body = explode( ' (', $font_body );
		if ( is_array( $font_body ) && 2 == count($font_body) ) {
			$fonts[] = urlencode( trim( $font_body[0] ) );
		}
	}
	if ( $font_heading && $font_heading != 'default' ) {
		$font_heading = str_replace( ')', '', $font_heading );
		$font_heading = explode( ' (', $font_heading );
		if ( is_array( $font_heading ) && 2 == count($font_heading) ) {
			$fonts[] = urlencode( trim( $font_heading[0] ) );
		}
	}
	if ( !empty( $fonts ) ) {
		$fonts = implode( '|', $fonts );
		echo '<link href="https://fonts.googleapis.com/css?family='.$fonts.'" rel="stylesheet" type="text/css">';
	}
}

add_action( 'wp_footer', 'landingpress_wp_footer_google_tag_manager', 105 );
function landingpress_wp_footer_google_tag_manager() {
	$gtm_id = get_theme_mod('landingpress_google_tag_manager_id');
	if ( !$gtm_id )
		return;
	$gtm_id = trim( $gtm_id );
?>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','<?php echo esc_attr( $gtm_id ); ?>');</script>
<!-- End Google Tag Manager -->
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?php echo esc_attr( $gtm_id ); ?>"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<?php
}

function landingpress_facebook_pixel_set_event( $event = '' ) {
	global $landingpress_fb_pixel_event;
	$landingpress_fb_pixel_event = $event;
}

function landingpress_facebook_pixel_get_event() {
	global $landingpress_fb_pixel_event;
	return $landingpress_fb_pixel_event;
}

function landingpress_facebook_pixel_set_data( $data = array() ) {
	global $landingpress_fb_pixel_data;
	$landingpress_fb_pixel_data = $data;
}

function landingpress_facebook_pixel_get_data() {
	global $landingpress_fb_pixel_data;
	return $landingpress_fb_pixel_data;
}

add_action( 'wp_head', 'landingpress_wp_head_facebook_pixels_set_event', 5 );
function landingpress_wp_head_facebook_pixels_set_event() {
	$fb_event = 'PageView';
	if ( is_singular() ) {
		$fb_event_singular = get_post_meta( get_the_ID(), '_landingpress_facebook-event', true );
		if ( $fb_event_singular ) {
			$fb_event = $fb_event_singular;
		}
	}
	landingpress_facebook_pixel_set_event( $fb_event );
}

add_action( 'wp_head', 'landingpress_wp_head_facebook_pixels', 100 );
function landingpress_wp_head_facebook_pixels() {
	if ( is_singular() ) {
		$fb_event = get_post_meta( get_the_ID(), '_landingpress_facebook-event', true );
	}
	$fb_position = apply_filters( "landingpress_facebook_pixel_position", 'head' );
	if ( $fb_position == 'head' || $fb_position == 'header' ) {
		landingpress_facebook_pixel_multiple();
		landingpress_facebook_pixel_main();
	}
}

add_action( 'wp_footer', 'landingpress_wp_footer_facebook_pixels', 100 );
function landingpress_wp_footer_facebook_pixels() {
	$fb_position = apply_filters( "landingpress_facebook_pixel_position", 'head' );
	if ( $fb_position == 'footer' ) {
		landingpress_facebook_pixel_multiple();
		landingpress_facebook_pixel_main();
	}
}

function landingpress_facebook_pixel_multiple() {
	if ( !is_singular() )
		return;

	$pixels = get_post_meta( get_the_ID(), '_landingpress_facebook-pixels', false );
	if ( !empty($pixels) && is_array($pixels) ) {
		foreach ($pixels as $pixel) {
			$fb_pixel_id = trim( $pixel['pixel_id'] );
			$fb_event = $pixel['pixel_event'] ? $pixel['pixel_event'] : 'PageView';
?>
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '<?php echo esc_attr( $fb_pixel_id ); ?>');
fbq('track', <?php echo landingpress_facebook_pixel_event_script( $fb_event ); ?>);
</script>
<noscript><img height="1" width="1" style="display:none" 
src="https://www.facebook.com/tr?id=<?php echo esc_attr( $fb_pixel_id ); ?><?php echo landingpress_facebook_pixel_event_noscript( $fb_event ); ?>&noscript=1" 
/></noscript>
<!-- End Facebook Pixel Code -->
<?php 
		}
	}
}

function landingpress_facebook_pixel_event_script( $fb_event = 'PageView', $fb_data = array() ) {
	if ( $fb_event == 'Purchase' && empty( $fb_data ) ) {
		$fb_data['value'] = '0.00';
		$fb_data['currency'] = 'USD';
	}
	$fb_event_script = '"'.$fb_event.'"';
	if ( !empty( $fb_data ) && is_array( $fb_data ) ) {
		$fb_event_script .= ', '.json_encode( $fb_data );
	}
	return $fb_event_script;
}

function landingpress_facebook_pixel_event_noscript( $fb_event = 'PageView', $fb_data = array() ) {
	if ( $fb_event == 'Purchase' && empty( $fb_data ) ) {
		$fb_data['value'] = '0.00';
		$fb_data['currency'] = 'USD';
	}
	$fb_event_noscript = '&ev='.$fb_event;
	if ( !empty( $fb_data ) && is_array( $fb_data ) ) {
		foreach ($fb_data as $fb_data_key => $fb_data_value) {
			if ( $fb_data_key && $fb_data_value ) {
				$fb_event_noscript .= '&cd['.$fb_data_key.']='.$fb_data_value;
			}
		}
	}
	return $fb_event_noscript;
}

function landingpress_facebook_pixel_main() {
	$fb_pixel_id = get_theme_mod('landingpress_facebook_pixel_id');
	if ( !$fb_pixel_id )
		return;
	$fb_pixel_id = trim( $fb_pixel_id );
	$fb_event = landingpress_facebook_pixel_get_event();
	$fb_data = landingpress_facebook_pixel_get_data();
?>
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '<?php echo esc_attr( $fb_pixel_id ); ?>');
fbq('track', <?php echo landingpress_facebook_pixel_event_script( $fb_event, $fb_data ); ?>);
</script>
<noscript><img height="1" width="1" style="display:none" 
src="https://www.facebook.com/tr?id=<?php echo esc_attr( $fb_pixel_id ); ?><?php echo landingpress_facebook_pixel_event_noscript( $fb_event, $fb_data ); ?>&noscript=1" 
/></noscript>
<!-- End Facebook Pixel Code -->
<?php 
}

if ( class_exists('djv_landingpro') ) {
	add_action( 'parse_request', 'landingpress_landingpro_parse_request' );
}
function landingpress_landingpro_parse_request() {
	add_filter('parse_query', 'landingpress_landingpro_parse_query');
}
function landingpress_landingpro_parse_query( $query ) {
	if ( $query->query_vars['post_type'] == 'page' && $query->is_page == false && $query->is_single == true ) {
		$query->is_page = true;
		$query->is_single = false;
	} 
	return $query;
}

add_filter( 'comment_form_fields', 'landingpress_comment_form_fields', 99 );
function landingpress_comment_form_fields( $fields ) {
	if ( get_theme_mod('landingpress_comment_url_hide') && isset( $fields['url'] ) ) {
		unset( $fields['url'] );
	}
	if ( get_theme_mod('landingpress_comment_textarea_reverse') && isset( $fields['comment'] ) ) {
		$comment_field = $fields['comment'];
		unset( $fields['comment'] );
		$fields['comment'] = $comment_field;
	}
	return $fields;
}

add_filter( 'comment_form_defaults', 'landingpress_comment_form_comment_form' );
function landingpress_comment_form_comment_form( $args ) {
	if ( get_theme_mod('landingpress_comment_form_title_reply') && isset($args['title_reply']) ) {
		$args['title_reply'] = get_theme_mod('landingpress_comment_form_title_reply');
	}
	if ( get_theme_mod('landingpress_comment_form_title_reply_to') && isset($args['title_reply_to']) ) {
		$args['title_reply_to'] = get_theme_mod('landingpress_comment_form_title_reply_to');
	}
	if ( get_theme_mod('landingpress_comment_form_cancel_reply_link') && isset($args['cancel_reply_link']) ) {
		$args['cancel_reply_link'] = get_theme_mod('landingpress_comment_form_cancel_reply_link');
	}
	if ( get_theme_mod('landingpress_comment_form_label_submit') && isset($args['label_submit']) ) {
		$args['label_submit'] = get_theme_mod('landingpress_comment_form_label_submit');
	}
	return $args;
}
