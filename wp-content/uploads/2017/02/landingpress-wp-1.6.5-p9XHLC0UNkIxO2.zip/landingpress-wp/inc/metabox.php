<?php 
/**
This is our function to load custom meta boxes for LandingPress
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


if ( class_exists( 'CMB_Meta_Box' ) ) {
	add_action( 'admin_notices', 'landingpress_metabox_active' );
}
else {
	if ( ! version_compare( PHP_VERSION, '5.4', '>=' ) ) {
		add_action( 'admin_notices', 'landingpress_metabox_fail_php_version' );
	} 
	else {
		define( 'CMB_DEV', false );
		define( 'CMB_PATH', trailingslashit( get_template_directory() ) . 'addons/metabox/' );
		define( 'CMB_URL', trailingslashit( get_template_directory_uri() ) . 'addons/metabox/' );
		require( CMB_PATH . 'custom-meta-boxes.php' );
	}
}

function landingpress_metabox_active() {
	$message = esc_html__( 'LandingPress use custom version of CMB. Please deactivate your CMB plugin.', 'landingpress' );
	$html_message = sprintf( '<div class="error">%s</div>', wpautop( $message ) );
	echo wp_kses_post( $html_message );
}

function landingpress_metabox_fail_php_version() {
	$message = esc_html__( 'LandingPress requires PHP version 5.4+.', 'landingpress' );
	$html_message = sprintf( '<div class="error">%s</div>', wpautop( $message ) );
	echo wp_kses_post( $html_message );
}

add_filter( 'cmb_meta_boxes', 'landingpress_cmb_meta_boxes' );
function landingpress_cmb_meta_boxes( array $meta_boxes ) {

	// _elementor_edit_mode = builder

	$fields = array(
		array( 'id' => '_landingpress_hide_sidebar',  'name' => 'Hide Sidebar', 'type' => 'radio', 'options' => array( '' => 'default', 'yes' => 'yes' ) ),
		array( 'id' => '_landingpress_hide_header',  'name' => 'Hide Header', 'type' => 'radio', 'options' => array( '' => 'default', 'yes' => 'yes' ) ),
		array( 'id' => '_landingpress_hide_menu',  'name' => 'Hide Header Menu', 'type' => 'radio', 'options' => array( '' => 'default', 'yes' => 'yes' ) ),
		array( 'id' => '_landingpress_hide_footerwidgets',  'name' => 'Hide Footer Widgets', 'type' => 'radio', 'options' => array( '' => 'default', 'yes' => 'yes' ) ),
		array( 'id' => '_landingpress_hide_footer',  'name' => 'Hide Footer', 'type' => 'radio', 'options' => array( '' => 'default', 'yes' => 'yes' ) ),
		array( 'id' => '_landingpress_hide_breadcrumb',  'name' => 'Hide Breadcrumb', 'type' => 'radio', 'options' => array( '' => 'default', 'yes' => 'yes' ) ),
		array( 'id' => '_landingpress_hide_title',  'name' => 'Hide Title', 'type' => 'radio', 'options' => array( '' => 'default', 'yes' => 'yes' ) ),
		array( 'id' => '_landingpress_hide_comments',  'name' => 'Hide Comments', 'type' => 'radio', 'options' => array( '' => 'default', 'yes' => 'yes' ) ),
		array( 'id' => '_landingpress_page_width',  'name' => 'Page Width', 'type' => 'radio', 'options' => array( '' => 'default', '500' => '500px', '600' => '600px', '700' => '700px', '800' => '800px' ) ),
	);
	$meta_boxes[] = array(
		'id' => 'landingpress-layout',
		'title' => 'Page Layout Settings',
		'pages' => array( 'post', 'page' ),
		'fields' => $fields,
		'priority'   => 'low',
		'hide_on' => array( 'page-template' => array( 'page_landingpress.php', 'page_landingpress_boxed.php', 'page_landingpress_slim.php' ) ),
	);

	$fbevents = array(
		'' => 'PageView (default)',
		'ViewContent' => 'ViewContent',
		'AddToCart' => 'AddToCart',
		'AddToWishlist' => 'AddToWishlist',
		'InitiateCheckout' => 'InitiateCheckout',
		'AddPaymentInfo' => 'AddPaymentInfo',
		'Purchase' => 'Purchase',
		'Lead' => 'Lead',
		'CompleteRegistration' => 'CompleteRegistration',
	);
	$fields = array(
		array( 'id' => '_landingpress_facebook-event',  'name' => __( 'Facebook Pixel Event (Main Pixel from Appearance - Customize page)', 'landingpress'), 'type' => 'select', 'options' => $fbevents, 'desc' => __('Note: Main pixel will be loaded in the LAST sequence. This is important to make sure that any button tracking event will be attributed to this main pixel', 'landingpress') ),
		array( 'id' => '_landingpress_facebook-pixels', 'name' => 'Multiple Facebook Pixels', 'type' => 'group', 'cols' => 12, 'fields' => array(
			array( 'id' => 'pixel_id',  'name' => 'Facebook Pixel ID', 'type' => 'text', 'cols' => 6 ),
			array( 'id' => 'pixel_event',  'name' => 'Facebook Pixel Event', 'type' => 'select', 'options' => $fbevents, 'cols' => 6 ),
		), 'repeatable' => true, 'repeatable_max' => 10, 'sortable' => true, 'string-repeat-field' => 'Add Facebook Pixel', 'string-delete-field' => 'Delete Facebook Pixel' ),
	);
	$meta_boxes[] = array(
		'id' => 'landingpress-facebook-pixel',
		'title' => 'Facebook Pixel Settings',
		'pages' => array( 'post', 'page', 'product' ),
		'fields' => $fields,
		'priority'   => 'low',
	);

	// _yoast_wpseo_opengraph-title
	// _yoast_wpseo_opengraph-description
	// _yoast_wpseo_opengraph-image
	$fields = array(
		array( 'id' => '_landingpress_facebook-image',  'name' => 'Facebook Image', 'type' => 'image' ),
		array( 'id' => '_landingpress_facebook-title',  'name' => 'Facebook Title', 'type' => 'text' ),
		array( 'id' => '_landingpress_facebook-description',  'name' => 'Facebook Description', 'type' => 'textarea' ),
	);
	$meta_boxes[] = array(
		'id' => 'landingpress-facebook-sharing',
		'title' => 'Facebook Sharing (Open Graph) Settings',
		'pages' => array( 'post', 'page', 'product' ),
		'fields' => $fields,
		'priority'   => 'low',
	);

	if ( ! ( defined('WPSEO_VERSION') || class_exists('All_in_One_SEO_Pack') || class_exists('All_in_One_SEO_Pack_p') || class_exists('HeadSpace_Plugin') || class_exists('Platinum_SEO_Pack') || class_exists('SEO_Ultimate') ) ) {
		// _yoast_wpseo_meta-robots-noindex
		// _yoast_wpseo_meta-robots-nofollow
		// _yoast_wpseo_title
		// _yoast_wpseo_metadesc
		$fields = array(
			array( 'id' => '_landingpress_meta-title',  'name' => 'Meta Title', 'type' => 'text' ),
			array( 'id' => '_landingpress_meta-description',  'name' => 'Meta Description', 'type' => 'textarea' ),
			array( 'id' => '_landingpress_meta-keywords',  'name' => 'Meta Keywords', 'type' => 'text' ),
			array( 'id' => '_landingpress_meta-index',  'name' => 'Meta Robots Index', 'type' => 'select', 'options' => array( 'index' => 'index', 'noindex' => 'noindex' ), 'allow_none' => false, 'cols' => 6 ),
			array( 'id' => '_landingpress_meta-follow',  'name' => 'Meta Robots Follow', 'type' => 'select', 'options' => array( 'follow' => 'follow', 'nofollow' => 'nofollow' ), 'allow_none' => false, 'cols' => 6 ),
		);
		$meta_boxes[] = array(
			'id' => 'landingpress-seo',
			'title' => 'On-Page SEO Settings',
			'pages' => array( 'post', 'page', 'product' ),
			'fields' => $fields,
			'priority'   => 'low',
		);
	}

	$fields = array(
		array( 'id' => '_landingpress_redirect',  'name' => 'Redirect URL', 'type' => 'text' ),
	);
	$meta_boxes[] = array(
		'id' => 'landingpress-redirect',
		'title' => 'Redirect Settings',
		'pages' => array( 'post', 'page', 'product' ),
		'fields' => $fields,
		'priority'   => 'low',
	);

	return $meta_boxes;

}
