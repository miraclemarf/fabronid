<?php
/**
 * @package LandingPress
 */

$readmore = get_theme_mod( 'landingpress_archive_morelink_text' );
if ( !$readmore ) {
	$readmore = __( 'Continue reading &rarr;', 'landingpress' );
}

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header">

		<?php 
		$img_opt = get_theme_mod( 'landingpress_archive_image', 'featured' );
		if ( 'none' != $img_opt ) :
			if ( 'thumb-left' == $img_opt ) :
				echo landingpress_get_image( array( 'alt' => get_the_title(), 'link' => 'post', 'size' => 'thumbnail', 'class' => 'alignleft', 'fallback' => 'attachment' ) ); 
			elseif ( 'thumb-right' == $img_opt ) :
				echo landingpress_get_image( array( 'alt' => get_the_title(), 'link' => 'post', 'size' => 'thumbnail', 'class' => 'alignright', 'fallback' => 'attachment' ) ); 
			else :
				echo landingpress_get_image( array( 'alt' => get_the_title(), 'link' => 'post', 'fallback' => 'attachment' ) ); 
			endif;
		endif; 
		?>

		<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>

		<?php if ( get_theme_mod( 'landingpress_archive_meta', '1' ) ) : ?>
			<div class="entry-meta">
				<?php echo landingpress_get_entry_meta(); ?>
			</div>
		<?php endif; ?>

	</header>

	<?php do_action( 'landingpress_entry_content_before' ); ?>

	<div class="entry-content">
		<?php if ( 'excerpt' == get_theme_mod( 'landingpress_archive_content' ) ) : ?>
			<?php the_excerpt(); ?>
			<?php if ( get_theme_mod( 'landingpress_archive_morelink', '1' ) ) : ?>
				<p><a href="<?php the_permalink(); ?>" class="more-link"><?php echo esc_attr( $readmore ); ?></a></p>
			<?php endif; ?>
		<?php else : ?>
			<?php the_content( $readmore ); ?>
			<?php landingpress_link_pages(); ?>
		<?php endif; ?>
	</div>

	<?php do_action( 'landingpress_entry_content_after' ); ?>

</article>
