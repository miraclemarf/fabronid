<?php
/**
This is our function to load custom version of Elementor for LandingPress
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( get_theme_mod('landingpress_pagebuilder_elementor_disable') ) {
	return;
}

if ( get_option( LANDINGPRESS_THEME_SLUG . '_license_key_status', false) != 'valid' ) {
	return;
}

if ( class_exists( 'Elementor\\Plugin' ) ) {
	add_action( 'admin_notices', 'landingpress_elementor_active' );
}
else {
	if ( ! version_compare( PHP_VERSION, '5.4', '>=' ) ) {
		add_action( 'admin_notices', 'landingpress_elementor_fail_php_version' );
	} 
	// elseif ( ini_get( 'asp_tags' ) ) {
	// 	add_action( 'admin_notices', 'landingpress_elementor_fail_server_configuration_problem' );
	// } 
	else {
		define( 'ELEMENTOR_VERSION', '1.0.12' );
		define( 'ELEMENTOR_TEMPLATES_PATH', trailingslashit( get_template_directory() ) . 'addons/elementor-templates/contents/' );

		define( 'ELEMENTOR_PLUGIN_BASE', 'elementor' );
		define( 'ELEMENTOR_URL', trailingslashit( get_template_directory_uri() ) . 'addons/elementor/' );
		define( 'ELEMENTOR_PATH', trailingslashit( get_template_directory() ) . 'addons/elementor/' );
		define( 'ELEMENTOR_ASSETS_URL', ELEMENTOR_URL . 'assets/' );
		require_once( ELEMENTOR_PATH . 'includes/plugin.php' );
		add_filter('pre_option_elementor_allow_tracking', 'landingpress_elementor_allow_tracking' ); 
		if ( class_exists( 'Elementor\\Tracker' ) ) {
			remove_action( 'admin_notices', array( 'Elementor\\Tracker', 'admin_notices' ) );
		}
		if ( class_exists( 'Elementor\\Frontend' ) ) {
			add_action( 'wp_enqueue_scripts', 'landingpress_elementor_dequeue', 999 );
		}
		add_filter( 'gettext', 'landingpress_elementor_gettext', 20, 3 );
		if ( ! class_exists( 'WP_Post_Meta_Revisioning' ) ) {
			include_once( trailingslashit( get_template_directory() ) . 'addons/wp-post-meta-revisions/wp-post-meta-revisions.php' );
			add_filter( 'wp_post_revision_meta_keys', 'landingpress_elementor_post_revision_meta_keys' );
		}
		add_action('dp_duplicate_page', 'landingpress_dp_duplicate_post', 15, 2);
		add_action('dp_duplicate_post', 'landingpress_dp_duplicate_post', 15, 2);
		if ( in_array( 'elementor-pro/elementor-pro.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
			if ( defined('ELEMENTOR_PRO_PATH') ) {
				if ( file_exists( ELEMENTOR_PRO_PATH . 'plugin.php' ) ) {
					require_once( ELEMENTOR_PRO_PATH . 'plugin.php' );
					if ( function_exists('elementor_pro_fail_load') ) {
						remove_action( 'admin_notices', 'elementor_pro_fail_load' );
					}
				}
			}
		}
	}
}

add_action( 'admin_notices', 'landingpress_elementor_notices' );
function landingpress_elementor_notices() {
	$screen = get_current_screen();
	if ( $screen->id == 'toplevel_page_elementor' || $screen->id == 'elementor_page_elementor-system-info' ) {
		$message = esc_html__( 'LandingPress uses custom version of Elementor with many enhancements. LandingPress team is responsible for Elementor updates.', 'landingpress' );
		$html_message = sprintf( '<div class="notice notice-info">%s</div>', wpautop( $message ) );
		echo wp_kses_post( $html_message );
	}
}

function landingpress_elementor_active() {
	$message = esc_html__( 'LandingPress uses custom version of Elementor. Please deactivate your Elementor plugin.', 'landingpress' );
	$html_message = sprintf( '<div class="error">%s</div>', wpautop( $message ) );
	echo wp_kses_post( $html_message );
}

function landingpress_elementor_fail_php_version() {
	$message = esc_html__( 'Page Builder requires PHP version 5.4+, Page Builder is currently NOT ACTIVE.', 'landingpress' );
	$html_message = sprintf( '<div class="error">%s</div>', wpautop( $message ) );
	echo wp_kses_post( $html_message );
}

function landingpress_elementor_fail_server_configuration_problem() {
	$message = esc_html__( 'Server Configuration Problem: asp_tags is enabled, but is not compatible with Page Builder. You can disable `asp_tags` in `.htaccess` or `php.ini` file.', 'landingpress' );
	$html_message = sprintf( '<div class="error">%s</div>', wpautop( $message ) );
	echo wp_kses_post( $html_message );
}

function landingpress_elementor_allow_tracking( $option ) {
	return 'no';
}

function landingpress_elementor_dequeue() {
	if ( is_singular() && 'builder' == get_post_meta( get_the_ID(), '_elementor_edit_mode', true ) ) 
		return;
	wp_dequeue_script( 'elementor-frontend' );
	wp_dequeue_style( 'elementor-animations' );
	wp_dequeue_style( 'elementor-icons' );
	wp_dequeue_style( 'elementor-frontend' );
	wp_enqueue_style( 'font-awesome' );
	/* Elementor Pro */
	wp_dequeue_script( 'elementor-pro-frontend' );
	wp_dequeue_style( 'elementor-pro' );
}

// add_filter('pre_option_elementor_disable_color_schemes', 'landingpress_elementor_disable_color_schemes' ); 
function landingpress_elementor_disable_color_schemes( $option ) {
	return 'yes';
}

// add_filter('pre_option_elementor_disable_typography_schemes', 'landingpress_elementor_disable_typography_schemes' ); 
function landingpress_elementor_disable_typography_schemes( $option ) {
	return 'yes';
}

function landingpress_elementor_gettext( $translated_text, $text, $domain ) {
	switch ( $translated_text ) {
		case 'Edit with Elementor' :
			$translated_text = 'Edit with LandingPress Elementor';
			break;
		case 'Current header' :
			$translated_text = 'Current Header Image';
			break;
	}
	return $translated_text;
}

function landingpress_elementor_post_revision_meta_keys( $keys ) {
    $keys[] = '_elementor_data';
    $keys[] = '_elementor_draft_data';
    $keys[] = '_elementor_edit_mode';
    $keys[] = '_elementor_version';
    return $keys;
}

function landingpress_dp_duplicate_post($new_post_id, $post) {
	$data = get_post_meta($post->ID, '_elementor_data', true);
	if ( is_string( $data ) && ! empty( $data ) ) {
		$data = wp_slash( $data );
		update_post_meta($new_post_id, '_elementor_data', $data);
	}
	$draft_data = get_post_meta($post->ID, '_elementor_draft_data', true);
	if ( is_string( $draft_data ) && ! empty( $draft_data ) ) {
		$draft_data = wp_slash( $draft_data );
		update_post_meta($new_post_id, '_elementor_draft_data', $draft_data);
	}
}
