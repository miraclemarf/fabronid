<?php 

add_filter( 'landingpress_elementor_templates_data', 'landingpress_elementor_templates_data' );
function landingpress_elementor_templates_data( $templates ) {

	$templates[] = array (
		'id' => 'template-properti',
		'title' => 'Properti',
		'url' => '//id.landingpress.net/template/properti/',
	);

	$templates[] = array (
		'id' => 'template-toko-kue',
		'title' => 'Toko Kue',
		'url' => '//id.landingpress.net/template/toko-kue/',
	);

	$templates[] = array (
		'id' => 'template-hotel',
		'title' => 'Hotel',
		'url' => '//id.landingpress.net/template/hotel/',
	);

	$templates[] = array (
		'id' => 'template-kambing-kurban',
		'title' => 'Kambing Kurban',
		'url' => '//id.landingpress.net/template/kambing-kurban/',
	);

	$templates[] = array (
		'id' => 'template-produk-kesehatan',
		'title' => 'Produk Kesehatan',
		'url' => '//id.landingpress.net/template/produk-kesehatan/',
	);

	return $templates;
}

add_filter( 'landingpress_elementor_sections_data', 'landingpress_elementor_sections_data' );
function landingpress_elementor_sections_data( $templates ) {

	$templates[] = array (
		'id' => 'headline-light',
		'title' => 'Headline (Light)',
		'url' => '//id.landingpress.net/template/headline-light-preview/',
	);

	$templates[] = array (
		'id' => 'headline-dark',
		'title' => 'Headline (Dark)',
		'url' => '//id.landingpress.net/template/headline-dark-preview/',
	);

	$templates[] = array (
		'id' => 'headline-bg-image-light',
		'title' => 'Headline + Background Image (Light)',
		'url' => '//id.landingpress.net/template/headline-background-image-light-preview/',
	);

	$templates[] = array (
		'id' => 'headline-bg-image-dark',
		'title' => 'Headline + Background Image (Dark)',
		'url' => '//id.landingpress.net/template/headline-background-image-dark-preview/',
	);

	$templates[] = array (
		'id' => 'headline-bg-video-light',
		'title' => 'Headline + Background Video (Light)',
		'url' => '//id.landingpress.net/template/headline-background-video-light-preview/',
	);

	$templates[] = array (
		'id' => 'headline-bg-video-dark',
		'title' => 'Headline + Background Video (Dark)',
		'url' => '//id.landingpress.net/template/headline-background-video-dark-preview/',
	);

	$templates[] = array (
		'id' => 'headline-hero-image-light',
		'title' => 'Headline + Hero Image (Light)',
		'url' => '//id.landingpress.net/template/headline-hero-image-light-preview/',
	);

	$templates[] = array (
		'id' => 'headline-hero-image-dark',
		'title' => 'Headline + Hero Image (Dark)',
		'url' => '//id.landingpress.net/template/headline-hero-image-dark-preview/',
	);

	$templates[] = array (
		'id' => 'headline-hero-video-light',
		'title' => 'Headline + Hero Video (Light)',
		'url' => '//id.landingpress.net/template/headline-hero-video-light-preview/',
	);

	$templates[] = array (
		'id' => 'headline-hero-video-dark',
		'title' => 'Headline + Hero Video (Dark)',
		'url' => '//id.landingpress.net/template/headline-hero-video-dark-preview/',
	);

	$templates[] = array (
		'id' => 'cekresi-cekresicom',
		'title' => 'Cek Resi - CekResi.Com (Default)',
		'url' => 'http://id.landingpress.net/template/cek-resi-cekresi-com-default/',
	);

	$templates[] = array (
		'id' => 'cekresi-cekresicom2',
		'title' => 'Cek Resi - CekResi.Com (Custom)',
		'url' => '//id.landingpress.net/template/cek-resi-cekresi-com-custom/',
	);

	$templates[] = array (
		'id' => 'cekongkir-rajaongkir',
		'title' => 'Cek Ongkir - Raja Ongkir',
		'url' => 'http://id.landingpress.net/template/cek-ongkir-rajaongkir-free-widget/',
	);

	$templates[] = array (
		'id' => 'cekongkirresi-ibacor',
		'title' => 'Cek Ongkir&Resi - iBacor',
		'url' => 'http://id.landingpress.net/template/cek-ongkir-resi-ibacor/',
	);

	$templates[] = array (
		'id' => 'cekongkirresi-piresta',
		'title' => 'Cek Ongkir&Resi - Piresta',
		'url' => '//id.landingpress.net/template/cek-ongkir-resi-piresta/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-01',
		'title' => 'Hero UI Kit 01',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-01-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-02',
		'title' => 'Hero UI Kit 02',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-02-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-03',
		'title' => 'Hero UI Kit 03',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-03-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-04',
		'title' => 'Hero UI Kit 04',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-04-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-05',
		'title' => 'Hero UI Kit 05',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-05-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-06',
		'title' => 'Hero UI Kit 06',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-06-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-07',
		'title' => 'Hero UI Kit 07',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-07-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-08',
		'title' => 'Hero UI Kit 08',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-08-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-09',
		'title' => 'Hero UI Kit 09',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-09-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-10',
		'title' => 'Hero UI Kit 10',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-10-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-11',
		'title' => 'Hero UI Kit 11',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-11-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-12',
		'title' => 'Hero UI Kit 12',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-12-preview/',
	);

	return $templates;
}
