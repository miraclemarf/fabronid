<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package LandingPress
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header">
		<?php do_action( 'landingpress_entry_header_page_before' ); ?>
		<?php if( landingpress_is_title_active() ) the_title( '<h1 class="entry-title">', '</h1>' ); ?>
		<?php do_action( 'landingpress_entry_header_page_after' ); ?>
	</header>

	<?php do_action( 'landingpress_entry_content_page_before' ); ?>

	<div class="entry-content">
		<?php the_content(); ?>
		<?php landingpress_link_pages(); ?>
		<?php edit_post_link( __( 'Edit', 'landingpress' ), '<span class="edit-link">', '</span>' ); ?>
	</div>

	<?php do_action( 'landingpress_entry_content_page_after' ); ?>
	
</article>
