<?php
/**
 * Template Name: Boxed Canvas + Header&Footer
 */

add_action( 'body_class', 'landingpress_body_class_template_blank' );
function landingpress_body_class_template_blank( $classes ) {
	$classes[] = 'page-landingpress page-landingpress-boxed-hf';
	return $classes;
}
add_filter('landingpress_is_sidebar_active', '__return_true');
get_header(); 
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main">

	<?php if ( have_posts() ) : ?>

		<?php while ( have_posts() ) : the_post(); ?>

			<?php the_content(); ?>

		<?php endwhile; ?>

	<?php else : ?>

	<?php endif; ?>

	</main>
</div>

<?php get_footer(); ?>
