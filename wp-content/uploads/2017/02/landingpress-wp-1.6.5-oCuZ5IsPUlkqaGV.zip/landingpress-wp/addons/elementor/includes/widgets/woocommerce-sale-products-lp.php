<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_Woocommerce_sale_products_lp extends Widget_Base {

	public function get_name() {
		return 'woocommerce_products_sale_lp';
	}

	public function get_title() {
		return __( 'WooCommerce - On Sale Products', 'elementor' );
	}

	public function get_icon() {
		return 'eicon-woocommerce';
	}

	public function get_categories() {
		return [ 'landingpress' ];
	}

	public static function get_product_categories() {
		$categories = array( '' => __( '- All Categories -', 'elementor' ) );
		$terms = get_terms( array( 'taxonomy' => 'product_cat' ) );
		if ( !empty($terms) ) {
			foreach ( $terms as $term ) {
				$categories[$term->slug] = $term->name;
			}
		}
		return $categories;
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'section_products',
			[
				'label' => __( 'On Sale Products', 'elementor' ),
			]
		);

		$this->add_control(
			'category',
			[
				'label' => __( 'Category', 'elementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => self::get_product_categories(),
			]
		);

		$options = array();
		for ($i=1; $i <=6; $i++) { 
			$options[$i] = $i;
		}

		$this->add_control(
			'columns',
			[
				'label' => __( 'Columns Per Row', 'elementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => '4',
				'options' => $options,
			]
		);
		for ($i=7; $i <=24; $i++) { 
			$options[$i] = $i;
		}

		$this->add_control(
			'per_page',
			[
				'label' => __( 'Number of Products', 'elementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => '4',
				'options' => $options,
			]
		);

		$this->add_control(
			'orderby',
			[
				'label' => __( 'Order By', 'elementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'title',
				'options' => [
					'title' => __( 'Title', 'elementor' ),
					'date' => __( 'Published Date', 'elementor' ),
					'rand' => __( 'Random', 'elementor' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label' => __( 'Order', 'elementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'ASC',
				'options' => [
					'ASC' => __( 'ASC (low to high)', 'elementor' ),
					'DESC' => __( 'DESC (high to low)', 'elementor' ),
				],
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings();

		if ( Plugin::instance()->editor->is_edit_mode() ) {
			if ( class_exists('woocommerce') && function_exists('landingpress_wc_setup_shop_page') ) {
				landingpress_wc_setup_shop_page();
			} 
			if ( class_exists('woocommerce') && function_exists('landingpress_wc_product_post_class') ) {
				add_filter( 'post_class', 'landingpress_wc_product_post_class', 20 ); 
			} 
		}

		$shortcode_tag = 'sale_products';

		$this->add_render_attribute( 'wrapper', 'class', 'elementor-woocommerce-lp' );

		if ( isset($settings['category']) && $settings['category'] ) {
			$this->add_render_attribute( 'shortcode', 'category', $settings['category'] );
		}

		if ( $settings['columns'] ) {
			$this->add_render_attribute( 'shortcode', 'columns', $settings['columns'] );
		}

		if ( $settings['per_page'] ) {
			$this->add_render_attribute( 'shortcode', 'per_page', $settings['per_page'] );
		}

		if ( $settings['orderby'] ) {
			$this->add_render_attribute( 'shortcode', 'orderby', $settings['orderby'] );
		}

		if ( $settings['order'] ) {
			$this->add_render_attribute( 'shortcode', 'order', $settings['order'] );
		}

		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<?php echo do_shortcode( '['.$shortcode_tag.' ' . $this->get_render_attribute_string( 'shortcode' ) . ']' ); ?>
		</div>
		<?php
	}

	protected function _content_template() {}
}
