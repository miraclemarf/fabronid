<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package LandingPress
 */

?>

<div id="secondary" class="widget-area">
	<div class="site-sidebar">
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
	</div>
</div>
