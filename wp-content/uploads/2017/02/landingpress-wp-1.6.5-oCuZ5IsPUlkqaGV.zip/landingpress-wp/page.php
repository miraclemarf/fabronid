<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package LandingPress
 */

get_header(); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main">

	<?php if ( have_posts() ) : ?>

		<?php do_action( 'landingpress_content_before' ); ?>

		<?php while ( have_posts() ) : the_post(); ?>

			<?php do_action( 'landingpress_entry_page_before' ); ?>

			<?php get_template_part( 'content', 'page' ); ?>

			<?php do_action( 'landingpress_entry_page_after' ); ?>

		<?php endwhile; ?>

		<?php do_action( 'landingpress_content_after' ); ?>

	<?php else : ?>

		<?php get_template_part( 'content', 'none' ); ?>

	<?php endif; ?>

	</main>
</div>

<?php if ( landingpress_is_sidebar_active() ) get_sidebar(); ?>
<?php get_footer(); ?>
