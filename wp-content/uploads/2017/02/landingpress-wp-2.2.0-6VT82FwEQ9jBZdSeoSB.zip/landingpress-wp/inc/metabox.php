<?php 

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

add_filter( 'cmb_meta_boxes', 'landingpress_cmb_meta_boxes' );
function landingpress_cmb_meta_boxes( array $meta_boxes ) {

	// _elementor_edit_mode = builder

	$fields = array(
		array( 
			'id' => '_landingpress_hide_sidebar',  
			'name' => esc_html__( 'Hide Sidebar', 'landingpress-wp' ), 
			'type' => 'radio', 
			'options' => array( 
				'' => esc_html__( 'default', 'landingpress-wp' ), 
				'yes' => esc_html__( 'yes', 'landingpress-wp' ), 
			) 
		),
		array( 
			'id' => '_landingpress_hide_header',  
			'name' => esc_html__( 'Hide Header', 'landingpress-wp' ), 
			'type' => 'radio', 
			'options' => array( 
				'' => esc_html__( 'default', 'landingpress-wp' ), 
				'yes' => esc_html__( 'yes', 'landingpress-wp' ), 
			) 
		),
		array( 
			'id' => '_landingpress_hide_menu',  
			'name' => esc_html__( 'Hide Header Menu', 'landingpress-wp' ), 
			'type' => 'radio', 
			'options' => array( 
				'' => esc_html__( 'default', 'landingpress-wp' ), 
				'yes' => esc_html__( 'yes', 'landingpress-wp' ), 
			) 
		),
		array( 
			'id' => '_landingpress_hide_footerwidgets',  
			'name' => esc_html__( 'Hide Footer Widgets', 'landingpress-wp' ), 
			'type' => 'radio', 
			'options' => array( 
				'' => esc_html__( 'default', 'landingpress-wp' ), 
				'yes' => esc_html__( 'yes', 'landingpress-wp' ), 
			) 
		),
		array( 
			'id' => '_landingpress_hide_footer',  
			'name' => esc_html__( 'Hide Footer', 'landingpress-wp' ), 
			'type' => 'radio', 
			'options' => array( 
				'' => esc_html__( 'default', 'landingpress-wp' ), 
				'yes' => esc_html__( 'yes', 'landingpress-wp' ), 
			) 
		),
		array( 
			'id' => '_landingpress_hide_breadcrumb',  
			'name' => esc_html__( 'Hide Breadcrumb', 'landingpress-wp' ), 
			'type' => 'radio', 
			'options' => array( 
				'' => esc_html__( 'default', 'landingpress-wp' ), 
				'yes' => esc_html__( 'yes', 'landingpress-wp' ), 
			) 
		),
		array( 
			'id' => '_landingpress_hide_title',  
			'name' => esc_html__( 'Hide Title', 'landingpress-wp' ), 
			'type' => 'radio', 
			'options' => array( 
				'' => esc_html__( 'default', 'landingpress-wp' ), 
				'yes' => esc_html__( 'yes', 'landingpress-wp' ), 
			) 
		),
		array( 
			'id' => '_landingpress_hide_comments',  
			'name' => esc_html__( 'Hide Comments', 'landingpress-wp' ), 
			'type' => 'radio', 
			'options' => array( 
				'' => esc_html__( 'default', 'landingpress-wp' ), 
				'yes' => esc_html__( 'yes', 'landingpress-wp' ), 
			) 
		),
		array( 
			'id' => '_landingpress_page_width',  
			'name' => esc_html__( 'Page Width', 'landingpress-wp' ), 
			'type' => 'radio', 
			'options' => array( 
				'' => esc_html__( 'default', 'landingpress-wp' ), 
				'500' => '500px', 
				'600' => '600px', 
				'700' => '700px', 
				'800' => '800px'
			) 
		),
	);
	$meta_boxes[] = array(
		'id' => 'landingpress-layout',
		'title' => esc_html__( 'Page Layout Settings', 'landingpress-wp' ),
		'pages' => array( 'post', 'page' ),
		'fields' => $fields,
		'priority'   => 'low',
		'hide_on' => array( 
			'page-template' => array( 
				'page_landingpress.php', 
				'page_landingpress_boxed.php', 
				'page_landingpress_slim.php' 
			) 
		),
	);

	$fbevents = array(
		'' => 'PageView '.esc_html__( '(default)', 'landingpress-wp' ),
		'ViewContent' => 'ViewContent',
		'AddToCart' => 'AddToCart',
		'AddToWishlist' => 'AddToWishlist',
		'InitiateCheckout' => 'InitiateCheckout',
		'AddPaymentInfo' => 'AddPaymentInfo',
		'Purchase' => 'Purchase',
		'Lead' => 'Lead',
		'CompleteRegistration' => 'CompleteRegistration',
	);
	$fields = array(
		array( 
			'id' => '_landingpress_facebook-event',  
			'name' => esc_html__( 'Facebook Pixel Event (Main Pixel from Appearance - Customize page)', 'landingpress-wp'), 
			'type' => 'select', 
			'options' => $fbevents, 
			'desc' => esc_html__('Note: Main pixel will be loaded in the LAST sequence. This is important to make sure that any button tracking event will be attributed to this main pixel', 'landingpress-wp') 
		),
		array( 
			'id' => '_landingpress_facebook-pixels', 
			'name' => esc_html__( 'Multiple Facebook Pixels', 'landingpress-wp'), 
			'type' => 'group', 'cols' => 12, 
			'fields' => array(
				array( 
					'id' => 'pixel_id',  
					'name' => esc_html__( 'Facebook Pixel ID', 'landingpress-wp'), 
					'type' => 'text', 
					'cols' => 6 
				),
				array( 
					'id' => 'pixel_event',  
					'name' => esc_html__( 'Facebook Pixel Event', 'landingpress-wp'), 
					'type' => 'select', 
					'options' => $fbevents, 
					'cols' => 6 
				),
			), 
			'repeatable' => true, 
			'repeatable_max' => 10, 
			'sortable' => true, 
			'string-repeat-field' => esc_html__( 'Add Facebook Pixel', 'landingpress-wp'), 
			'string-delete-field' => esc_html__( 'Delete Facebook Pixel' , 'landingpress-wp'),
		),
	);
	$meta_boxes[] = array(
		'id' => 'landingpress-facebook-pixel',
		'title' => esc_html__( 'Facebook Pixel Settings', 'landingpress-wp'),
		'pages' => array( 'post', 'page', 'product' ),
		'fields' => $fields,
		'priority'   => 'low',
	);

	// _yoast_wpseo_opengraph-title
	// _yoast_wpseo_opengraph-description
	// _yoast_wpseo_opengraph-image
	$fields = array(
		array( 
			'id' => '_landingpress_facebook-image', 
			'name' => esc_html__( 'Facebook Image', 'landingpress-wp'), 
			'type' => 'image' 
		),
		array( 
			'id' => '_landingpress_facebook-title', 
			'name' => esc_html__( 'Facebook Title', 'landingpress-wp'), 
			'type' => 'text' 
		),
		array( 
			'id' => '_landingpress_facebook-description', 
			'name' => esc_html__( 'Facebook Description', 'landingpress-wp'), 
			'type' => 'textarea' 
		),
	);
	$meta_boxes[] = array(
		'id' => 'landingpress-facebook-sharing',
		'title' => esc_html__( 'Facebook Sharing (Open Graph) Settings', 'landingpress-wp'),
		'pages' => array( 'post', 'page', 'product' ),
		'fields' => $fields,
		'priority'   => 'low',
	);

	if ( ! ( defined('WPSEO_VERSION') || class_exists('All_in_One_SEO_Pack') || class_exists('All_in_One_SEO_Pack_p') || class_exists('HeadSpace_Plugin') || class_exists('Platinum_SEO_Pack') || class_exists('SEO_Ultimate') ) ) {
		// _yoast_wpseo_meta-robots-noindex
		// _yoast_wpseo_meta-robots-nofollow
		// _yoast_wpseo_title
		// _yoast_wpseo_metadesc
		$fields = array(
			array( 
				'id' => '_landingpress_meta-title', 
				'name' => esc_html__( 'Meta Title', 'landingpress-wp'), 
				'type' => 'text' 
			),
			array( 
				'id' => '_landingpress_meta-description', 
				'name' => esc_html__( 'Meta Description', 'landingpress-wp'), 
				'type' => 'textarea' 
			),
			array( 
				'id' => '_landingpress_meta-keywords', 
				'name' => esc_html__( 'Meta Keywords', 'landingpress-wp'), 
				'type' => 'text' 
			),
			array( 
				'id' => '_landingpress_meta-index', 
				'name' => esc_html__( 'Meta Robots Index', 'landingpress-wp'), 
				'type' => 'select', 
				'options' => array( 
					'index' => 'index', 
					'noindex' => 'noindex' 
				), 
				'allow_none' => false, 
				'cols' => 6 
			),
			array( 
				'id' => '_landingpress_meta-follow', 
				'name' => esc_html__( 'Meta Robots Follow', 'landingpress-wp'), 
				'type' => 'select', 
				'options' => array( 
					'follow' => 'follow', 
					'nofollow' => 'nofollow' 
				), 
				'allow_none' => false, 
				'cols' => 6 
			),
		);
		$meta_boxes[] = array(
			'id' => 'landingpress-seo',
			'title' => esc_html__( 'On-Page SEO Settings', 'landingpress-wp'),
			'pages' => array( 'post', 'page', 'product' ),
			'fields' => $fields,
			'priority'   => 'low',
		);
	}

	$fields = array(
		array( 
			'id' => '_landingpress_redirect', 
			'name' => esc_html__( 'Redirect URL', 'landingpress-wp'), 
			'type' => 'text' 
		),
	);
	$meta_boxes[] = array(
		'id' => 'landingpress-redirect',
		'title' => esc_html__( 'Redirect Settings', 'landingpress-wp'),
		'pages' => array( 'post', 'page', 'product' ),
		'fields' => $fields,
		'priority'   => 'low',
	);

	return $meta_boxes;

}
