<?php 

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

add_filter( 'landingpress_elementor_templates_data', 'landingpress_elementor_templates_data' );
function landingpress_elementor_templates_data( $templates ) {

	//---------------------------------------------------------------------------------
	$templates[] = array (
		'id' => 'template-001-apps',
		'title' => 'Aplikasi',
		'url' => '//id.landingpress.net/template/template-001/',
	);

	$templates[] = array (
		'id' => 'template-002-simple-product-launch',
		'title' => 'Produk Launch',
		'url' => '//id.landingpress.net/template/template-002-simple-product-launch/',
	);

	$templates[] = array (
		'id' => 'template-003-coming-soon-light',
		'title' => 'Coming Soon (Light)',
		'url' => '//id.landingpress.net/template/template-003-coming-soon-light/',
	);

	$templates[] = array (
		'id' => 'template-004-coming-soon-video',
		'title' => 'Coming Soon (Video)',
		'url' => '//id.landingpress.net/template/template-004-coming-soon-video/',
	);

	$templates[] = array (
		'id' => 'template-005-company',
		'title' => 'Company',
		'url' => '//id.landingpress.net/template/template-005-company/',
	);

	$templates[] = array (
		'id' => 'template-006-event',
		'title' => 'Event',
		'url' => '//id.landingpress.net/template/template-006-event/',
	);

	//--------------------------------------------------------------------------------

	$templates[] = array (
		'id' => 'template-properti',
		'title' => 'Properti',
		'url' => '//id.landingpress.net/template/properti/',
	);

	$templates[] = array (
		'id' => 'template-toko-kue',
		'title' => 'Toko Kue',
		'url' => '//id.landingpress.net/template/toko-kue/',
	);

	$templates[] = array (
		'id' => 'template-hotel',
		'title' => 'Hotel',
		'url' => '//id.landingpress.net/template/hotel/',
	);

	$templates[] = array (
		'id' => 'template-kambing-kurban',
		'title' => 'Kambing Kurban',
		'url' => '//id.landingpress.net/template/kambing-kurban/',
	);

	$templates[] = array (
		'id' => 'template-produk-kesehatan',
		'title' => 'Produk Kesehatan',
		'url' => '//id.landingpress.net/template/produk-kesehatan/',
	);

	return $templates;
}

add_filter( 'landingpress_elementor_sections_data', 'landingpress_elementor_sections_data' );
function landingpress_elementor_sections_data( $templates ) {

	//header----------------------------------------------------------------------
	$templates[] = array (
		'id' => 'header-01',
		'title' => 'Header 01',
		'url' => '//id.landingpress.net/template/header-01/',
	);

	$templates[] = array (
		'id' => 'header-02',
		'title' => 'Header 02',
		'url' => '//id.landingpress.net/template/header-02/',
	);

	$templates[] = array (
		'id' => 'header-03',
		'title' => 'Header 03',
		'url' => '//id.landingpress.net/template/header-03/',
	);

	$templates[] = array (
		'id' => 'header-04',
		'title' => 'Header 04',
		'url' => '//id.landingpress.net/template/header-04/',
	);

	$templates[] = array (
		'id' => 'header-05',
		'title' => 'Header 05',
		'url' => '//id.landingpress.net/template/header-05-movie/',
	);

	$templates[] = array (
		'id' => 'header-06',
		'title' => 'Header 06',
		'url' => '//id.landingpress.net/template/header-06/',
	);

	$templates[] = array (
		'id' => 'header-07',
		'title' => 'Header 07',
		'url' => '//id.landingpress.net/template/header-07/',
	);

	$templates[] = array (
		'id' => 'header-08',
		'title' => 'Header 08',
		'url' => '//id.landingpress.net/template/header-08/',
	);

	$templates[] = array (
		'id' => 'header-09',
		'title' => 'Header 09',
		'url' => '//id.landingpress.net/template/header-09/',
	);

	$templates[] = array (
		'id' => 'header-10',
		'title' => 'Header 10',
		'url' => '//id.landingpress.net/template/header-10/',
	);

	//footer----------------------------------------------------------------------
	$templates[] = array (
		'id' => 'footer-01',
		'title' => 'Footer 01',
		'url' => '//id.landingpress.net/template/footer-01/',
	);

	$templates[] = array (
		'id' => 'footer-02',
		'title' => 'Footer 02',
		'url' => '//id.landingpress.net/template/footer-02/',
	);

	$templates[] = array (
		'id' => 'footer-03',
		'title' => 'Footer 03',
		'url' => '//id.landingpress.net/template/footer-03/',
	);

	$templates[] = array (
		'id' => 'footer-04',
		'title' => 'Footer 04',
		'url' => '//id.landingpress.net/template/footer-04/',
	);

	$templates[] = array (
		'id' => 'footer-05',
		'title' => 'Footer 05',
		'url' => '//id.landingpress.net/template/footer-05/',
	);

	$templates[] = array (
		'id' => 'footer-06',
		'title' => 'Footer 06',
		'url' => '//id.landingpress.net/template/footer-06/',
	);

	$templates[] = array (
		'id' => 'footer-07',
		'title' => 'Footer 07',
		'url' => '//id.landingpress.net/template/footer-07/',
	);

	$templates[] = array (
		'id' => 'footer-08',
		'title' => 'Footer 08',
		'url' => '//id.landingpress.net/template/footer-08/',
	);

	$templates[] = array (
		'id' => 'footer-09',
		'title' => 'Footer 09',
		'url' => '//id.landingpress.net/template/footer-09/',
	);

	$templates[] = array (
		'id' => 'footer-10',
		'title' => 'Footer 10',
		'url' => '//id.landingpress.net/template/footer-10/',
	);

	//pricing----------------------------------------------------------------------
	$templates[] = array (
		'id' => 'pricing-01',
		'title' => 'Pricing 01',
		'url' => '//id.landingpress.net/template/pricing-01/',
	);

	$templates[] = array (
		'id' => 'pricing-02',
		'title' => 'Pricing 02',
		'url' => '//id.landingpress.net/template/pricing-02/',
	);

	$templates[] = array (
		'id' => 'pricing-03',
		'title' => 'Pricing 03',
		'url' => '//id.landingpress.net/template/pricing-03/',
	);

	$templates[] = array (
		'id' => 'pricing-04',
		'title' => 'Pricing 04',
		'url' => '//id.landingpress.net/template/pricing-04/',
	);

	$templates[] = array (
		'id' => 'pricing-05',
		'title' => 'Pricing 05',
		'url' => '//id.landingpress.net/template/pricing-05/',
	);

	$templates[] = array (
		'id' => 'pricing-06',
		'title' => 'Pricing 06',
		'url' => '//id.landingpress.net/template/pricing-06/',
	);

	$templates[] = array (
		'id' => 'pricing-07',
		'title' => 'Pricing 07',
		'url' => '//id.landingpress.net/template/pricing-07/',
	);

	$templates[] = array (
		'id' => 'pricing-08',
		'title' => 'Pricing 08',
		'url' => '//id.landingpress.net/template/pricing-08/',
	);

	$templates[] = array (
		'id' => 'pricing-09',
		'title' => 'Pricing 09',
		'url' => '//id.landingpress.net/template/pricing-09/',
	);

	$templates[] = array (
		'id' => 'pricing-10',
		'title' => 'Pricing 10',
		'url' => '//id.landingpress.net/template/pricing-10/',
	);

	//features----------------------------------------------------------------------
	$templates[] = array (
		'id' => 'feature-01',
		'title' => 'Feature 01',
		'url' => '//id.landingpress.net/template/feature-01/',
	);

	$templates[] = array (
		'id' => 'feature-02',
		'title' => 'Feature 02',
		'url' => '//id.landingpress.net/template/feature-02/',
	);

	$templates[] = array (
		'id' => 'feature-03',
		'title' => 'Feature 03',
		'url' => '//id.landingpress.net/template/feature-03/',
	);

	$templates[] = array (
		'id' => 'feature-04',
		'title' => 'Feature 04',
		'url' => '//id.landingpress.net/template/feature-04/',
	);

	$templates[] = array (
		'id' => 'feature-05',
		'title' => 'Feature 05',
		'url' => '//id.landingpress.net/template/feature-05/',
	);

	$templates[] = array (
		'id' => 'feature-06',
		'title' => 'Feature 06',
		'url' => '//id.landingpress.net/template/feature-06/',
	);

	$templates[] = array (
		'id' => 'feature-07',
		'title' => 'Feature 07',
		'url' => '//id.landingpress.net/template/feature-07/',
	);

	$templates[] = array (
		'id' => 'feature-08',
		'title' => 'Feature 08',
		'url' => '//id.landingpress.net/template/feature-08/',
	);


	//project-----------------------------------------------------------------------
	$templates[] = array (
		'id' => 'project-01',
		'title' => 'Project 01',
		'url' => '//id.landingpress.net/template/project-01/',
	);

	$templates[] = array (
		'id' => 'project-02',
		'title' => 'Project 02',
		'url' => '//id.landingpress.net/template/project-02/',
	);

	$templates[] = array (
		'id' => 'project-03',
		'title' => 'Project 03',
		'url' => '//id.landingpress.net/template/project-03/',
	);

	$templates[] = array (
		'id' => 'project-04',
		'title' => 'Project 04',
		'url' => '//id.landingpress.net/template/project-04/',
	);

	$templates[] = array (
		'id' => 'project-05',
		'title' => 'Project 05',
		'url' => '//id.landingpress.net/template/project-05/',
	);

	$templates[] = array (
		'id' => 'project-06',
		'title' => 'Project 06',
		'url' => '//id.landingpress.net/template/project-06/',
	);

	$templates[] = array (
		'id' => 'project-07',
		'title' => 'Project 07',
		'url' => '//id.landingpress.net/template/project-07/',
	);

	$templates[] = array (
		'id' => 'project-08',
		'title' => 'Project 08',
		'url' => '//id.landingpress.net/template/project-08/',
	);


	//team--------------------------------------------------------------------------
	$templates[] = array (
		'id' => 'team-01',
		'title' => 'Team 01',
		'url' => '//id.landingpress.net/template/team-01/',
	);

	$templates[] = array (
		'id' => 'team-02',
		'title' => 'Team 02',
		'url' => '//id.landingpress.net/template/team-02/',
	);

	$templates[] = array (
		'id' => 'team-03',
		'title' => 'Team 03',
		'url' => '//id.landingpress.net/template/team-03/',
	);

	$templates[] = array (
		'id' => 'team-04',
		'title' => 'Team 04',
		'url' => '//id.landingpress.net/template/team-04/',
	);

	$templates[] = array (
		'id' => 'team-05',
		'title' => 'Team 05',
		'url' => '//id.landingpress.net/template/team-05/',
	);

	$templates[] = array (
		'id' => 'team-06',
		'title' => 'Team 06',
		'url' => '//id.landingpress.net/template/team-06/',
	);

	$templates[] = array (
		'id' => 'team-07',
		'title' => 'Team 07',
		'url' => '//id.landingpress.net/template/team-07/',
	);

	$templates[] = array (
		'id' => 'team-08',
		'title' => 'Team 08',
		'url' => '//id.landingpress.net/template/team-08/',
	);

	$templates[] = array (
		'id' => 'team-09',
		'title' => 'Team 09',
		'url' => '//id.landingpress.net/template/team-09/',
	);

	//testimonials------------------------------------------------------------------
	$templates[] = array (
		'id' => 'testimonials-01',
		'title' => 'Testimonials 01',
		'url' => '//id.landingpress.net/template/testimonial-01/',
	);

	$templates[] = array (
		'id' => 'testimonials-02',
		'title' => 'Testimonials 02',
		'url' => '//id.landingpress.net/template/testimonial-02/',
	);

	$templates[] = array (
		'id' => 'testimonials-03',
		'title' => 'Testimonials 03',
		'url' => '//id.landingpress.net/template/testimonial-03/',
	);

	$templates[] = array (
		'id' => 'testimonials-04',
		'title' => 'Testimonials 04',
		'url' => '//id.landingpress.net/template/testimonial-04/',
	);

	$templates[] = array (
		'id' => 'testimonials-05',
		'title' => 'Testimonials 05',
		'url' => '//id.landingpress.net/template/testimonial-05/',
	);

	$templates[] = array (
		'id' => 'testimonials-06',
		'title' => 'Testimonials 06',
		'url' => '//id.landingpress.net/template/testimonial-06/',
	);

	$templates[] = array (
		'id' => 'testimonials-07',
		'title' => 'Testimonials 07',
		'url' => '//id.landingpress.net/template/testimonial-07/',
	);

	//end---------------------------------------------------------------------------

	$templates[] = array (
		'id' => 'headline-light',
		'title' => 'Headline (Light)',
		'url' => '//id.landingpress.net/template/headline-light-preview/',
	);

	$templates[] = array (
		'id' => 'headline-dark',
		'title' => 'Headline (Dark)',
		'url' => '//id.landingpress.net/template/headline-dark-preview/',
	);

	$templates[] = array (
		'id' => 'headline-bg-image-light',
		'title' => 'Headline + Background Image (Light)',
		'url' => '//id.landingpress.net/template/headline-background-image-light-preview/',
	);

	$templates[] = array (
		'id' => 'headline-bg-image-dark',
		'title' => 'Headline + Background Image (Dark)',
		'url' => '//id.landingpress.net/template/headline-background-image-dark-preview/',
	);

	$templates[] = array (
		'id' => 'headline-bg-video-light',
		'title' => 'Headline + Background Video (Light)',
		'url' => '//id.landingpress.net/template/headline-background-video-light-preview/',
	);

	$templates[] = array (
		'id' => 'headline-bg-video-dark',
		'title' => 'Headline + Background Video (Dark)',
		'url' => '//id.landingpress.net/template/headline-background-video-dark-preview/',
	);

	$templates[] = array (
		'id' => 'headline-hero-image-light',
		'title' => 'Headline + Hero Image (Light)',
		'url' => '//id.landingpress.net/template/headline-hero-image-light-preview/',
	);

	$templates[] = array (
		'id' => 'headline-hero-image-dark',
		'title' => 'Headline + Hero Image (Dark)',
		'url' => '//id.landingpress.net/template/headline-hero-image-dark-preview/',
	);

	$templates[] = array (
		'id' => 'headline-hero-video-light',
		'title' => 'Headline + Hero Video (Light)',
		'url' => '//id.landingpress.net/template/headline-hero-video-light-preview/',
	);

	$templates[] = array (
		'id' => 'headline-hero-video-dark',
		'title' => 'Headline + Hero Video (Dark)',
		'url' => '//id.landingpress.net/template/headline-hero-video-dark-preview/',
	);

	$templates[] = array (
		'id' => 'cekresi-cekresicom',
		'title' => 'Cek Resi - CekResi.Com (Default)',
		'url' => 'http://id.landingpress.net/template/cek-resi-cekresi-com-default/',
	);

	$templates[] = array (
		'id' => 'cekresi-cekresicom2',
		'title' => 'Cek Resi - CekResi.Com (Custom)',
		'url' => '//id.landingpress.net/template/cek-resi-cekresi-com-custom/',
	);

	$templates[] = array (
		'id' => 'cekongkir-rajaongkir',
		'title' => 'Cek Ongkir - Raja Ongkir',
		'url' => 'http://id.landingpress.net/template/cek-ongkir-rajaongkir-free-widget/',
	);

	$templates[] = array (
		'id' => 'cekongkirresi-ibacor',
		'title' => 'Cek Ongkir&Resi - iBacor',
		'url' => 'http://id.landingpress.net/template/cek-ongkir-resi-ibacor/',
	);

	$templates[] = array (
		'id' => 'cekongkirresi-piresta',
		'title' => 'Cek Ongkir&Resi - Piresta',
		'url' => '//id.landingpress.net/template/cek-ongkir-resi-piresta/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-01',
		'title' => 'Hero UI Kit 01',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-01-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-02',
		'title' => 'Hero UI Kit 02',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-02-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-03',
		'title' => 'Hero UI Kit 03',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-03-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-04',
		'title' => 'Hero UI Kit 04',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-04-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-05',
		'title' => 'Hero UI Kit 05',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-05-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-06',
		'title' => 'Hero UI Kit 06',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-06-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-07',
		'title' => 'Hero UI Kit 07',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-07-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-08',
		'title' => 'Hero UI Kit 08',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-08-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-09',
		'title' => 'Hero UI Kit 09',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-09-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-10',
		'title' => 'Hero UI Kit 10',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-10-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-11',
		'title' => 'Hero UI Kit 11',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-11-preview/',
	);

	$templates[] = array (
		'id' => 'elementor-herouikit-12',
		'title' => 'Hero UI Kit 12',
		'url' => '//id.landingpress.net/template/elementor-hero-ui-kit-12-preview/',
	);

	return $templates;
}
